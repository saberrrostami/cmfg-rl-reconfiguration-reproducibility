from pathlib import Path
import argparse,csv,json,sys,numpy as np,shutil
PKG=Path(__file__).resolve().parents[2]; CORE=PKG/'core';sys.path.insert(0,str(CORE));sys.path.insert(0,str(CORE/'scripts/final_design'))
from common import backbone
from src.final_design.env import FinalDesignEnv
from src.final_design.baselines import B6RollingHorizon,B6Config
CAPS=(0,1,2,500); VAL=range(70001,70009)
p=argparse.ArgumentParser();p.add_argument('--job-id',type=int,required=True);p.add_argument('--output-root',default='/content/RCAP_B6_GATE');a=p.parse_args()
if not 1<=a.job_id<=4: raise SystemExit('job-id 1..4')
B=CAPS[a.job_id-1]; b=backbone();cfg=B6Config(2,25,5.0,.05);rows=[]
for seed in VAL:
    e=FinalDesignEnv(b,seed,rho=.80,recovery_units=B,recovery_activation_h=.10,failure_mtbf_h=120.,recovery_mean_h=.35,split='validation')
    p6=B6RollingHorizon(cfg);d=e.next_decision();to=fb=dec=0;lat=[]
    while d is not None and not e.done:
        act,m=p6.select(e,d);dec+=1;to+=int(m.get('timeout',False));fb+=int('FALLBACK' in str(m.get('status','')));lat.append(float(m.get('wall_s',0.0)));d,_,_,_=e.step(int(act),shaped=False)
    mt=e.metrics();tel=e.structural_telemetry();rows.append({'B':B,'seed':seed,'cost':float(mt['cost_per_arrived']),'completion':float(mt['completion_fraction']),
      'timeouts':to,'fallbacks':fb,'decisions':dec,'median_latency_s':float(np.median(lat)) if lat else 0.,'p95_latency_s':float(np.quantile(lat,.95)) if lat else 0.,
      'recovery_utilization_fraction':float(tel.get('recovery_utilization_fraction',0.)),'recovery_full_capacity_time_fraction':float(tel.get('recovery_full_capacity_time_fraction',0.))})
out=Path(a.output_root)/f'B6_GATE_B{B}';out.mkdir(parents=True,exist_ok=True)
with (out/f'B6_GATE_B{B}.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'protocol':'RCAP-SENS-v1.0','B':B,'n_seeds':8,'timeouts':sum(r['timeouts'] for r in rows),'fallbacks':sum(r['fallbacks'] for r in rows),'decisions':sum(r['decisions'] for r in rows)}
summary['fallback_rate']=summary['fallbacks']/max(1,summary['decisions']);summary['pass']=bool(summary['timeouts']==0 and summary['fallback_rate']<=.01)
(out/f'B6_GATE_B{B}.json').write_text(json.dumps(summary,indent=2))
base=Path('/content')/f'RCAP_B6_GATE_B{B}';shutil.make_archive(str(base),'zip',root_dir=out.parent,base_dir=out.name)
print(json.dumps({**summary,'zip':str(base)+'.zip'},indent=2))
