from pathlib import Path
import argparse,json,zipfile,shutil
p=argparse.ArgumentParser();p.add_argument('--input-root',required=True);p.add_argument('--training-gate-dir',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args()
root=Path(a.input_root);td=Path(a.training_gate_dir);out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True);work=out/'_b6_unpacked';shutil.rmtree(work,ignore_errors=True);work.mkdir()
for z in root.rglob('RCAP_B6_GATE_B*.zip'):
    with zipfile.ZipFile(z) as f:f.extractall(work)
tg=json.loads((td/'RCAP_TRAINING_GATE.json').read_text()); bsum={}
for B in [0,1,2,500]:
    hits=list(work.rglob(f'B6_GATE_B{B}.json'))
    if len(hits)!=1:raise SystemExit(f'MISSING B6 GATE B={B}')
    bsum[str(B)]=json.loads(hits[0].read_text())
status='PASS_OPEN_FINAL' if tg.get('status')=='PASS' and all(bsum[str(B)].get('pass') for B in [0,1,2,500]) else 'REVIEW_REQUIRED'
g={**tg,'status':status,'b6_capacity_gate':bsum}
(out/'RCAP_FINAL_GATE.json').write_text(json.dumps(g,indent=2))
# copy selected policies into final gate dir
for f in td.glob('B*_PPO_seed_*_SELECTED.pt'):shutil.copy2(f,out/f.name)
for f in td.glob('B*_PPO_seed_*_REPORT.json'):shutil.copy2(f,out/f.name)
print(json.dumps(g,indent=2))
