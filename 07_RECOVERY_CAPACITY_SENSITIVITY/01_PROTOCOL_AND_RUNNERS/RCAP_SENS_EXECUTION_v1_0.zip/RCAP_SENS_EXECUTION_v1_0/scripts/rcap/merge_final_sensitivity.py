from pathlib import Path
import argparse,csv,json,zipfile,shutil,numpy as np
p=argparse.ArgumentParser();p.add_argument('--input-root',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args();root=Path(a.input_root);out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True);work=out/'_unpacked';shutil.rmtree(work,ignore_errors=True);work.mkdir()
for z in root.rglob('RCAP_FINAL_JOB_*.zip'):
    with zipfile.ZipFile(z) as f:f.extractall(work)
rows=[]
for j in range(1,11):
    hits=list(work.rglob(f'RCAP_FINAL_JOB_{j:02d}.csv'))
    if len(hits)!=1:raise SystemExit(f'MISSING_OR_DUPLICATE FINAL JOB {j}')
    with hits[0].open() as f:rows+=list(csv.DictReader(f))
if len(rows)!=200:raise SystemExit(f'EXPECTED 200 ROWS, GOT {len(rows)}')
for B in [0,1,2,500]:
    seeds=sorted(int(r['seed']) for r in rows if int(r['B'])==B)
    if seeds!=list(range(990001,990051)):raise SystemExit(f'SEED FIREWALL FAIL B={B}')
rng=np.random.default_rng(991001);R=50000

def bootstrap_mean(x):
    x=np.asarray(x,float);idx=rng.integers(0,len(x),size=(R,len(x)));b=x[idx].mean(1);return [float(x.mean()),*map(float,np.quantile(b,[.025,.975]))]

def paired_effect(x,q):
    x=np.asarray(x,float);q=np.asarray(q,float);d=x-q;rel=100*(q-x)/q;idx=rng.integers(0,len(x),size=(R,len(x)));return {'mean_abs_diff':float(d.mean()),'abs_ci':list(map(float,np.quantile(d[idx].mean(1),[.025,.975]))),'mean_rel_reduction_pct':float(rel.mean()),'rel_ci':list(map(float,np.quantile(rel[idx].mean(1),[.025,.975])))}
summary=[];details={}
for B in [0,1,2,500]:
    rr=sorted([r for r in rows if int(r['B'])==B],key=lambda r:int(r['seed']))
    ppo=np.array([float(r['ppo_family_mean_cost']) for r in rr]);b6=np.array([float(r['b6_cost']) for r in rr]);pc=np.array([float(r['ppo_family_mean_completion']) for r in rr]);bc=np.array([float(r['b6_completion']) for r in rr]);frozen=np.array([float(r['frozen_B1_deploy_cost']) for r in rr]);fcomp=np.array([float(r['frozen_B1_deploy_completion']) for r in rr])
    eff=paired_effect(ppo,b6);cd=100*(pc-bc);ce=bootstrap_mean(cd)
    z={'B':B,'n':50,'ppo_family_mean_cost':float(ppo.mean()),'b6_mean_cost':float(b6.mean()),**eff,'completion_diff_pp':ce[0],'completion_ci_pp':[ce[1],ce[2]],
      'frozen_B1_deploy_mean_cost':float(frozen.mean()),'frozen_B1_deploy_completion':float(fcomp.mean()),
      'ppo_recovery_utilization':float(np.mean([float(r['ppo_family_recovery_utilization']) for r in rr])),'ppo_full_capacity_time_fraction':float(np.mean([float(r['ppo_family_recovery_full_capacity_time_fraction']) for r in rr])),
      'b6_recovery_utilization':float(np.mean([float(r['b6_recovery_utilization']) for r in rr])),'b6_full_capacity_time_fraction':float(np.mean([float(r['b6_recovery_full_capacity_time_fraction']) for r in rr])),
      'b6_timeouts':sum(int(r['b6_timeouts']) for r in rr),'b6_fallbacks':sum(int(r['b6_fallbacks']) for r in rr)}
    summary.append(z);details[str(B)]=z
# fixed-policy capacity contrasts relative to non-binding B=500 on the same seeds
base=sorted([r for r in rows if int(r['B'])==500],key=lambda r:int(r['seed']));base_cost=np.array([float(r['frozen_B1_deploy_cost']) for r in base])
for z in summary:
    B=z['B'];rr=sorted([r for r in rows if int(r['B'])==B],key=lambda r:int(r['seed']));x=np.array([float(r['frozen_B1_deploy_cost']) for r in rr]);d=x-base_cost;tmp=bootstrap_mean(d);z['frozen_B1_cost_diff_vs_nonbinding']=tmp[0];z['frozen_B1_cost_diff_vs_nonbinding_ci']=[tmp[1],tmp[2]]
with (out/'RCAP_SENSITIVITY_TABLE.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
with (out/'RCAP_SENSITIVITY_ROWS.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/'RCAP_SENSITIVITY_RESULTS.json').write_text(json.dumps({'protocol':'RCAP-SENS-v1.0','capacities':[0,1,2,500],'heldout_seed_range':[990001,990050],'summary':summary},indent=2))
print(json.dumps(summary,indent=2))
