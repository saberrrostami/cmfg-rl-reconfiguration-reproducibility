from pathlib import Path
import argparse,csv,json,sys,torch,numpy as np,shutil
PKG=Path(__file__).resolve().parents[2];CORE=PKG/'core';sys.path.insert(0,str(CORE));sys.path.insert(0,str(CORE/'scripts/final_design'))
from common import backbone
from src.final_design.env import FinalDesignEnv
from src.final_design.obs import ObsBuilder,ObsSpec
from src.final_design.rl import PPO,PPOConfig
from src.final_design.baselines import B6RollingHorizon,B6Config
CAPS=(0,1,2,500); SEEDS=(1001,1002,1003,1004,1005)
p=argparse.ArgumentParser();p.add_argument('--gate-dir',required=True);p.add_argument('--job-id',type=int,required=True);p.add_argument('--output-root',default='/content/RCAP_FINAL');a=p.parse_args()
if not 1<=a.job_id<=10: raise SystemExit('job-id 1..10')
gd=Path(a.gate_dir);g=json.loads((gd/'RCAP_FINAL_GATE.json').read_text());
if g.get('status')!='PASS_OPEN_FINAL':raise SystemExit('FINAL GATE NOT OPEN')
start=990001+(a.job_id-1)*5; eval_seeds=range(start,start+5); b=backbone();device='cuda' if torch.cuda.is_available() else 'cpu';ob=ObsBuilder(ObsSpec(),b.calibration_slack_scale_h,b.median_operation_h);cfg=B6Config(2,25,5.0,.05)

def load_agent(path):
    z=torch.load(path,map_location=device,weights_only=False);ag=PPO(ObsSpec(),PPOConfig(),device);ag.net.load_state_dict(z['model']);ag.net.eval();return ag
agents={B:[(s,load_agent(gd/f'B{B}_PPO_seed_{s}_SELECTED.pt')) for s in SEEDS] for B in CAPS}
b1dep=int(g['capacity_training']['1']['deployment_training_seed']); frozen=load_agent(gd/f'B1_PPO_seed_{b1dep}_SELECTED.pt')

def env(seed,B):return FinalDesignEnv(b,seed,rho=.80,recovery_units=B,recovery_activation_h=.10,failure_mtbf_h=120.,recovery_mean_h=.35,split='heldout')
def eval_agent(seed,B,ag):
    e=env(seed,B);d=e.next_decision()
    while d is not None and not e.done:
        act=int(ag.act_batch([ob.build(e,d)],det=True)[0][0]);d,_,_,_=e.step(act,shaped=False)
    return e.metrics(),e.structural_telemetry()
rows=[]
for seed in eval_seeds:
  for B in CAPS:
    pcs=[];pcomp=[];putil=[];pfull=[];per={};ledgers=[]
    for ts,ag in agents[B]:
        m,t=eval_agent(seed,B,ag);pcs.append(float(m['cost_per_arrived']));pcomp.append(float(m['completion_fraction']));putil.append(float(t.get('recovery_utilization_fraction',0.)));pfull.append(float(t.get('recovery_full_capacity_time_fraction',0.)))
        per[f'ppo_{ts}_cost']=pcs[-1];per[f'ppo_{ts}_completion']=pcomp[-1]
        arr=max(1,int(m['arrived']));ld={k:float(v)/arr for k,v in m['ledger'].items() if k!='total'};ledgers.append(ld)
        for k,v in ld.items():per[f'ppo_{ts}_{k}_per_arrived']=v
    fm,ft=eval_agent(seed,B,frozen)
    e=env(seed,B);pol=B6RollingHorizon(cfg);d=e.next_decision();to=fb=dec=0;lat=[]
    while d is not None and not e.done:
        act,mm=pol.select(e,d);dec+=1;to+=int(mm.get('timeout',False));fb+=int('FALLBACK' in str(mm.get('status','')));lat.append(float(mm.get('wall_s',0.0)));d,_,_,_=e.step(int(act),shaped=False)
    mb=e.metrics();tb=e.structural_telemetry();barr=max(1,int(mb['arrived']));bled={k:float(v)/barr for k,v in mb['ledger'].items() if k!='total'};famled={k:float(np.mean([x[k] for x in ledgers])) for k in ledgers[0]}
    row={'B':B,'seed':seed,**per,'ppo_family_mean_cost':float(np.mean(pcs)),'ppo_family_mean_completion':float(np.mean(pcomp)),
      'ppo_family_recovery_utilization':float(np.mean(putil)),'ppo_family_recovery_full_capacity_time_fraction':float(np.mean(pfull)),
      'frozen_B1_deploy_seed':b1dep,'frozen_B1_deploy_cost':float(fm['cost_per_arrived']),'frozen_B1_deploy_completion':float(fm['completion_fraction']),
      'frozen_B1_recovery_utilization':float(ft.get('recovery_utilization_fraction',0.)),'frozen_B1_recovery_full_capacity_time_fraction':float(ft.get('recovery_full_capacity_time_fraction',0.)),
      'b6_cost':float(mb['cost_per_arrived']),'b6_completion':float(mb['completion_fraction']),'b6_timeouts':to,'b6_fallbacks':fb,'b6_decisions':dec,
      'b6_recovery_utilization':float(tb.get('recovery_utilization_fraction',0.)),'b6_recovery_full_capacity_time_fraction':float(tb.get('recovery_full_capacity_time_fraction',0.)),
      'b6_median_latency_s':float(np.median(lat)) if lat else 0.,'b6_p95_latency_s':float(np.quantile(lat,.95)) if lat else 0.}
    for k,v in famled.items():row[f'ppo_family_{k}_per_arrived']=v
    for k,v in bled.items():row[f'b6_{k}_per_arrived']=v
    rows.append(row);print(json.dumps({'B':B,'seed':seed,'ppo':row['ppo_family_mean_cost'],'b6':row['b6_cost']}),flush=True)
out=Path(a.output_root)/f'FINAL_JOB_{a.job_id:02d}';out.mkdir(parents=True,exist_ok=True)
with (out/f'RCAP_FINAL_JOB_{a.job_id:02d}.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/f'RCAP_FINAL_JOB_{a.job_id:02d}.json').write_text(json.dumps({'protocol':'RCAP-SENS-v1.0','job_id':a.job_id,'seed_range':[start,start+4],'rows':rows},indent=2))
base=Path('/content')/f'RCAP_FINAL_JOB_{a.job_id:02d}';shutil.make_archive(str(base),'zip',root_dir=out.parent,base_dir=out.name);print('OUTPUT_ZIP',str(base)+'.zip')
