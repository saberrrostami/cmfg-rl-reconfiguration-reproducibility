from pathlib import Path
import argparse, json, shutil, sys

PKG=Path(__file__).resolve().parents[2]
CORE=PKG/'core'
sys.path.insert(0,str(CORE)); sys.path.insert(0,str(CORE/'scripts/final_design'))
from common import backbone
from src.final_design.train import train_ppo

CAPS=(0,2,500); SEEDS=(1001,1002,1003,1004,1005)
JOBS=[(b,s) for b in CAPS for s in SEEDS]

p=argparse.ArgumentParser()
p.add_argument('--job-id',type=int,required=True)
p.add_argument('--output-root',default='/content/RCAP_OUTPUTS')
a=p.parse_args()
if not 1 <= a.job_id <= len(JOBS): raise SystemExit(f'job-id must be 1..{len(JOBS)}')
B,seed=JOBS[a.job_id-1]
outroot=Path(a.output_root); outroot.mkdir(parents=True,exist_ok=True)
out=outroot/f'TRAIN_JOB_{a.job_id:02d}_B{B}_S{seed}'
out.mkdir(parents=True,exist_ok=True)

r=train_ppo(
    backbone(), seed, out,
    recovery_units=B,
    resume=False,
    max_steps_override=800000,
    checkpoint_steps_override=[200000,400000,600000,700000,800000],
    selection_steps_override=[600000,700000,800000],
    anneal_transitions_override=800000,
    n_envs_override=8,
)
r['rcap_capacity_B']=B
r['rcap_job_id']=a.job_id
(out/'RCAP_METADATA.json').write_text(json.dumps({
    'protocol':'RCAP-SENS-v1.0', 'job_id':a.job_id, 'B':B, 'seed':seed,
    'budget_transitions':800000, 'selection_steps':[600000,700000,800000],
    'validation_seeds':list(r.get('validation_seeds',[])),
    'selected_step':int(r['selected_step']),
    'selected_robust_score':float(r['selected_robust_score']),
    'completed_budget_and_numerically_valid':bool(r['completed_budget_and_numerically_valid']),
},indent=2))
zip_path=Path('/content')/f'RCAP_TRAIN_JOB_{a.job_id:02d}_B{B}_S{seed}'
shutil.make_archive(str(zip_path),'zip',root_dir=out.parent,base_dir=out.name)
print(json.dumps({'status':'DONE','job_id':a.job_id,'B':B,'seed':seed,'selected_step':r['selected_step'],'zip':str(zip_path)+'.zip'},indent=2))
