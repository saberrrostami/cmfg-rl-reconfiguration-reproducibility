from pathlib import Path
import argparse, json, shutil, zipfile

PKG=Path(__file__).resolve().parents[2]
CAPS=(0,1,2,500); SEEDS=(1001,1002,1003,1004,1005)
p=argparse.ArgumentParser();p.add_argument('--input-root',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args()
root=Path(a.input_root);out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
work=out/'_unpacked'; shutil.rmtree(work,ignore_errors=True);work.mkdir()
for z in root.rglob('RCAP_TRAIN_JOB_*.zip'):
    with zipfile.ZipFile(z) as f:f.extractall(work)

summary={}
for B in CAPS:
    rows=[]
    for seed in SEEDS:
        if B==1:
            rep=PKG/'original_B1'/f'PPO_seed_{seed}_REPORT.json'; ck=PKG/'original_B1'/f'PPO_seed_{seed}_SELECTED.pt'
        else:
            hits=list(work.rglob(f'TRAIN_JOB_*_B{B}_S{seed}/PPO_seed_{seed}_REPORT.json'))
            if len(hits)!=1: raise SystemExit(f'MISSING_OR_DUPLICATE_REPORT B={B} seed={seed}: {len(hits)}')
            rep=hits[0]; ck=rep.parent/f'PPO_seed_{seed}_SELECTED.pt'
        r=json.loads(rep.read_text())
        if int(r.get('steps_trained',0))!=800000 or not r.get('completed_budget_and_numerically_valid',False):
            raise SystemExit(f'INVALID_TRAINING B={B} seed={seed}')
        row={'seed':seed,'selected_step':int(r['selected_step']),'robust_score':float(r['selected_robust_score']),
             'median_cost':float(r['selected_validation_median_cost']),'stability_support':bool(r.get('late_training_stability_support',True))}
        rows.append(row)
        shutil.copy2(ck,out/f'B{B}_PPO_seed_{seed}_SELECTED.pt')
        shutil.copy2(rep,out/f'B{B}_PPO_seed_{seed}_REPORT.json')
    stable=sum(x['stability_support'] for x in rows)
    dep=min(rows,key=lambda x:(x['robust_score'],x['median_cost'],x['seed']))
    summary[str(B)]={'policies':rows,'stability_supported_seeds':stable,'deployment_training_seed':dep['seed'],
                     'training_gate_pass':bool(stable>=4),'deployment_selection_basis':'minimum selected development robust score; tie median then seed'}

status='PASS' if all(summary[str(B)]['training_gate_pass'] for B in CAPS) else 'REVIEW_REQUIRED'
g={'protocol':'RCAP-SENS-v1.0','status':status,'capacities':[0,1,2,500],'nonbinding_capacity':500,
   'training_seeds':list(SEEDS),'new_heldout_seeds':[990001,990050],'capacity_training':summary,
   'b6_fixed':{'lookahead_multiplier':2,'scenario_count':25,'time_limit_s':5.0,'mip_gap':0.05}}
(out/'RCAP_TRAINING_GATE.json').write_text(json.dumps(g,indent=2))
print(json.dumps(g,indent=2))
