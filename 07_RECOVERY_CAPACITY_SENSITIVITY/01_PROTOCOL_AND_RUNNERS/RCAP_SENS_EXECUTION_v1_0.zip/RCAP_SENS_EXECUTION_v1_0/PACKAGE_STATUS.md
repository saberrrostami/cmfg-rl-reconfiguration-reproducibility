# RCAP-SENS v1.0 — execution package

- Frozen capacities: B = 0, 1, 2, 500 (500 effectively non-binding).
- Original B=1 selected PPO checkpoints preserved; B=1 is not retrained.
- New full-budget PPO jobs: 15 = 3 capacities (0,2,500) x 5 seeds (1001..1005).
- Full budget: 800,000 transitions/job; late selection only at 600k, 700k, 800k.
- Fixed B6: 2x25, 5 s time limit, 5% MIP gap; no capacity-specific retuning.
- New held-out sensitivity seeds: 990001..990050.
- Diagnostic telemetry only: recovery utilization and full-capacity occupancy; transitions/reward/objective/action semantics unchanged.
- Local short smoke tests passed for environments B=0,1,2,500; PPO training path B=0,2,500; and B6 selections B=0,1,2,500.
- No sensitivity manuscript results are included; full runs remain to be executed.
