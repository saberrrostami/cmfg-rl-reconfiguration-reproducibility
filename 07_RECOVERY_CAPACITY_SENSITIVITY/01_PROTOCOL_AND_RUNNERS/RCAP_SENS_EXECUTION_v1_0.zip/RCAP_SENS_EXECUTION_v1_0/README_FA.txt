RCAP-SENS v1.0 — Recovery-capacity sensitivity for CMFG RL CIE paper

Frozen capacities: B = 0, 1, 2, 500 (500 = effectively non-binding).
B=1 uses the original five frozen selected PPO checkpoints. Do NOT retrain B=1.
New full-budget PPO training is required only for B=0, B=2, B=500: 15 jobs total.
Training seeds: 1001..1005; budget: 800,000 transitions each.
Development validation remains 70001..70008. Final sensitivity uses fresh held-out seeds 990001..990050.
B6 is fixed at 2x25, 5 s time limit, 5% MIP gap. It is checked but not re-tuned by capacity.

TRAIN JOB MAP:
1-5   => B=0, seeds 1001..1005
6-10  => B=2, seeds 1001..1005
11-15 => B=500, seeds 1001..1005

Never use smoke-run numbers in the manuscript.
