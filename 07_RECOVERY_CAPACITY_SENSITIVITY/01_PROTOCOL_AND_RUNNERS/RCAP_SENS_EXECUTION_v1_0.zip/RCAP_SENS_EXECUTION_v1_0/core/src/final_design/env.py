from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import copy, heapq, math, hashlib
import numpy as np
from .data import EmpiricalBackbone, OrderTemplate, MachineTemplate, P25_VOL, P75_VOL

EVENT_PRIO={'FAIL':0,'RECOVER':1,'COMPLETE':2,'ARRIVAL':3,'RECOMPOSE':4}

@dataclass
class ProviderState:
    idx:int; machine:MachineTemplate; available:bool=True; busy_until:float=0.0
    active_job:Optional[int]=None; queue:List[int]=field(default_factory=list)
    fail_count:int=0; recover_at:float=0.0

@dataclass
class JobState:
    jid:int; template:OrderTemplate; arrival:float; due:float; priority:int
    route:Tuple[str,...]; op_index:int=0; status:str='NOT_ARRIVED'; current_provider:Optional[int]=None
    current_mode:str='regular'; waiting_since:float=0.0; progress:float=0.0; completed_at:Optional[float]=None
    interrupted:bool=False; recovery_reserved:bool=False; decision_pending:bool=False
    pending_transfer_h:float=0.0
    exec_token:int=0
    # Execution bookkeeping is diagnostic/state-consistency metadata.  It does not
    # expose future stochastic information; it records the currently committed run.
    exec_started_at:Optional[float]=None
    exec_service_start_at:Optional[float]=None
    exec_complete_at:Optional[float]=None
    exec_service_h:float=0.0
    @property
    def done(self): return self.status=='COMPLETE'
    @property
    def op(self): return self.route[self.op_index]
    @property
    def remaining_ops(self): return max(0,len(self.route)-self.op_index)

@dataclass(frozen=True)
class Action:
    provider:int
    mode:str # regular|recovery
    keep:bool=False

@dataclass
class Decision:
    time:float; job_id:int; reason:str; actions:List[Action]; mask:np.ndarray

@dataclass
class Ledger:
    service:float=0.0; switch:float=0.0; recovery:float=0.0; restart:float=0.0; tardiness:float=0.0; terminal:float=0.0
    def total(self): return self.service+self.switch+self.recovery+self.restart+self.tardiness+self.terminal
    def dict(self): return dict(service=self.service,switch=self.switch,recovery=self.recovery,restart=self.restart,tardiness=self.tardiness,terminal=self.terminal,total=self.total())

class FinalDesignEnv:
    """Event-driven finite-horizon SMDP for Design Freeze v2.0.0.

    The environment exposes no realized future arrivals/failures. Jobs already admitted expose their
    remaining routes, enabling pipeline-pressure state without future leakage.
    """
    def __init__(self, backbone:EmpiricalBackbone, seed:int, rho:float=.80, recovery_units:int=1,
                 demand_volatility:str='moderate', horizon_h:float=8.0, hard_cap_h:float=13.0,
                 failure_mtbf_h:float=120.0, recovery_mean_h:float=.35, switching_kappa:float=.15, recovery_activation_h:float=.10,
                 episode_source:str='generated', split:str='calibration'):
        self.b=backbone; self.seed=int(seed); self.rng=np.random.default_rng(self.seed)
        self.rho=float(rho); self.recovery_units=int(recovery_units); self.recovery_free=int(recovery_units)
        self.horizon=float(horizon_h); self.hard_cap=float(hard_cap_h); self.failure_mtbf=float(failure_mtbf_h); self.recovery_mean=float(recovery_mean_h)
        self.kappa=float(switching_kappa); self.recovery_activation_h=float(recovery_activation_h); self.demand_volatility=demand_volatility; self.episode_source=episode_source; self.split=split
        self.now=0.0; self.providers=[ProviderState(i,m) for i,m in enumerate(backbone.machines)]
        self._feasible_template_op_cache={}
        self._static_criticality_cache=None
        self.jobs:Dict[int,JobState]={}; self.events=[]; self.eid=0; self.pending:Optional[Decision]=None; self.ledger=Ledger(); self.trace=[]
        self.recovery_active:Dict[int,float]={}; self.done=False; self.last_cost_time=0.0
        # Physical processing-time diagnostics are kept separate from the economic
        # objective, whose service component is completion-billed (see _complete).
        self._completed_processing_h=0.0
        self._wasted_processing_h=0.0
        # Primary demand uncertainty is a two-state continuous-time MMPP.  The
        # regime is observable operational context; future switches/arrivals are not.
        # The symmetric CTMC rate is chosen so P(no switch in 0.25 h)=0.93.
        self.regime_reference_h=.25
        self.regime_no_switch_reference=.93
        self.regime_switch_rate_h=-math.log(self.regime_no_switch_reference)/self.regime_reference_h
        raw_normal=2*P25_VOL/(P25_VOL+P75_VOL); raw_surge=2*P75_VOL/(P25_VOL+P75_VOL)
        alpha=.45
        self.demand_multipliers={
            'NORMAL':1.0+alpha*(raw_normal-1.0),
            'SURGE':1.0+alpha*(raw_surge-1.0),
        }
        # Stationary distribution is 50/50 for the symmetric CTMC. Use a dedicated
        # exogenous-demand RNG so policy actions never alter the demand path.
        drg=self._keyrng('demand-regime-init')
        self.regime='SURGE' if drg.random()<.5 else 'NORMAL'
        self.regime_segments=[(0.0,self.regime)]
        # Compatibility diagnostics only; scientific generation uses the CTMC rate.
        self.regime_update_h=self.regime_reference_h
        self.regime_stay=self.regime_no_switch_reference
        self._counter=0
        # Time-weighted Structural-Gate telemetry. These accumulators are diagnostic only
        # and do not alter transitions, rewards, or policies.
        self._telemetry_elapsed=0.0
        self._recovery_busy_time=0.0
        self._recovery_used_unit_time=0.0
        self._recovery_full_time=0.0
        self._cap_busy_time={}
        self._provider_busy_time={p.idx:0.0 for p in self.providers}
        self._provider_available_time={p.idx:0.0 for p in self.providers}
        self._cap_available_time={}
        self._init_failures(); self._init_jobs()

    def clone(self): return copy.deepcopy(self)
    def _push(self,t,typ,payload):
        self.eid+=1; heapq.heappush(self.events,(float(t),EVENT_PRIO[typ],self.eid,typ,payload))
    def _keyrng(self,*parts):
        raw='|'.join(map(str,(self.seed,)+parts)).encode(); x=int.from_bytes(hashlib.sha256(raw).digest()[:8],'little'); return np.random.default_rng(x)
    def _init_failures(self):
        for p in self.providers:
            rg=self._keyrng('fail',p.idx); t=float(rg.exponential(self.failure_mtbf))
            while t<self.hard_cap:
                d=float(rg.exponential(self.recovery_mean)); self._push(t,'FAIL',{'p':p.idx,'down':d}); t += d+float(rg.exponential(self.failure_mtbf))
    def _split_templates(self):
        ids={'calibration':self.b.calibration_ids,'validation':self.b.validation_ids,'heldout':self.b.heldout_ids}[self.split]
        return [self.b.order_by_id(i) for i in ids]
    def demand_multiplier(self,regime:Optional[str]=None):
        return float(self.demand_multipliers[self.regime if regime is None else regime])

    def regime_same_state_probability(self,h:float):
        """P(Z_{t+h}=Z_t | Z_t) for the symmetric two-state CTMC."""
        h=max(0.0,float(h)); q=self.regime_switch_rate_h
        return 0.5*(1.0+math.exp(-2.0*q*h))

    def regime_no_switch_probability(self,h:float):
        return math.exp(-self.regime_switch_rate_h*max(0.0,float(h)))

    def expected_regime_multiplier(self,h:float,regime:Optional[str]=None):
        """Expected instantaneous multiplier at t+h conditional on current regime."""
        z=self.regime if regime is None else regime; h=max(0.0,float(h)); q=self.regime_switch_rate_h
        m0=self.demand_multiplier(z)
        # Symmetric multipliers have stationary mean exactly 1.
        return 1.0+(m0-1.0)*math.exp(-2.0*q*h)

    def expected_average_multiplier(self,window_h:float,regime:Optional[str]=None):
        """Average conditional demand multiplier over [t,t+window_h]."""
        h=max(1e-9,float(window_h)); q=self.regime_switch_rate_h
        m0=self.demand_multiplier(self.regime if regime is None else regime)
        return 1.0+(m0-1.0)*(1.0-math.exp(-2.0*q*h))/(2.0*q*h)

    def expected_arrivals(self,window_h:float,regime:Optional[str]=None):
        """Conditional expected *new* arrivals over the requested future window.

        New orders are admitted only until ``self.horizon``.  Forecast moments therefore
        shrink to zero as the current time approaches the admission cutoff and are exactly
        zero in the drain interval.  This prevents the policy from planning for arrivals
        that the simulator can no longer generate.
        """
        requested=max(0.0,float(window_h))
        h=min(requested,max(0.0,self.horizon-self.now))
        if h<=0.0: return 0.0
        return self.rho*self.b.base_arrival_rate_per_h*self.expected_average_multiplier(h,regime)*h

    def _init_jobs(self):
        if self.episode_source=='historical':
            for i,o in enumerate(self._split_templates()):
                if o.arrival_h<=self.horizon:
                    js=JobState(i,o,o.arrival_h,o.due_h,o.priority,o.route); self.jobs[i]=js; self._push(js.arrival,'ARRIVAL',{'j':i})
            return
        templates=self._split_templates(); base_rate=max(1e-4,self.rho*self.b.base_arrival_rate_per_h)
        rg=self._keyrng('demand-ctmc-mmpp')
        # Draw the stationary initial regime with the same dedicated exogenous stream.
        regime='SURGE' if rg.random()<.5 else 'NORMAL'
        self.regime=regime; self.regime_segments=[(0.0,regime)]
        t=0.0; jid=0; q=self.regime_switch_rate_h
        while t<self.horizon and jid<500:
            rate=max(1e-6,base_rate*self.demand_multiplier(regime))
            dt_arr=float(rg.exponential(1.0/rate))
            dt_switch=float(rg.exponential(1.0/q))
            if dt_switch < dt_arr:
                t += dt_switch
                if t>=self.horizon: break
                regime='NORMAL' if regime=='SURGE' else 'SURGE'
                self.regime_segments.append((float(t),regime))
                continue
            t += dt_arr
            if t>self.horizon: break
            o=templates[int(rg.integers(0,len(templates)))]
            # Preserve empirical due-date slack relative to the synthetic arrival.
            slack=max(.25,o.due_h-o.arrival_h); due=min(self.hard_cap+slack,t+slack)
            js=JobState(jid,o,float(t),float(due),o.priority,o.route); self.jobs[jid]=js; self._push(t,'ARRIVAL',{'j':jid}); jid+=1
        self.trace.append(('GENERATOR_CTMC_MMPP',len(self.jobs),base_rate,self.demand_multipliers,self.regime_switch_rate_h))

    def _proc_for_op(self,op): return 'P2' if op=='P2b' else op
    def _feasible_for_template_op(self,template,op):
        key=(int(template.order_id),str(op))
        z=self._feasible_template_op_cache.get(key)
        if z is None:
            proc=self._proc_for_op(op); out=[]
            for p in self.providers:
                if p.machine.process!=proc: continue
                if proc=='P1' and p.machine.color_limit is not None and p.machine.color_limit<template.colors: continue
                out.append(p.idx)
            z=tuple(out); self._feasible_template_op_cache[key]=z
        return z
    def feasible_providers(self,j:JobState):
        return list(self._feasible_for_template_op(j.template,j.op))
    def service_h(self,j:JobState,pidx:int):
        m=self.providers[pidx].machine
        raw=(j.template.running_meter/(m.min_speed*m.ratio_speed)+m.setup_min)/60.0
        from .data import TIME_SCALE
        return max(1e-4,raw*TIME_SCALE)
    def setup_transfer_h(self,j:JobState,pidx:int):
        # Setup time is already included in operation service time. A switch adds only transfer/recomposition delay,
        # scaled from a conservative fraction of dataset setup time to avoid double-counting.
        from .data import TIME_SCALE
        return .25*(self.providers[pidx].machine.setup_min/60.0)*TIME_SCALE
    def direct_cost(self,j:JobState,pidx:int,mode='regular'):
        # No empirical provider tariff is available. Use transparent unit processing-hour
        # cost rather than an arbitrary provider-index surcharge. Heterogeneity enters via
        # provider-dependent processing time; recovery carries a frozen 35% premium.
        c=self.service_h(j,pidx)
        if mode=='recovery': c*=1.35
        return c
    def provider_backlog_h(self,pidx:int,exclude_jid:Optional[int]=None):
        """Observable regular-capacity backlog before a newly appended job can start.

        Includes residual active work, downtime until recovery, and all queued work ahead.
        This quantity is deterministic from the current observable state and is shared by
        RL and every baseline.
        """
        p=self.providers[pidx]
        wait=max(0.0,p.busy_until-self.now)
        if not p.available:
            wait=max(wait,max(0.0,p.recover_at-self.now))
        for jid in p.queue:
            if exclude_jid is not None and jid==exclude_jid:
                break
            qj=self.jobs.get(jid)
            if qj is not None and not qj.done:
                wait += self.service_h(qj,pidx)+max(0.0,qj.pending_transfer_h)
        return wait

    def _set_execution_metadata(self,j:JobState,service_h:float,nonservice_h:float,complete_at:float):
        """Record the currently committed execution without changing dynamics.

        ``nonservice_h`` is activation/transfer time that precedes processing.  Keeping
        it separate lets terminal and failure diagnostics distinguish remaining service
        work from remaining wall-clock occupation.
        """
        j.exec_started_at=float(self.now)
        j.exec_service_start_at=float(self.now)+max(0.0,float(nonservice_h))
        j.exec_complete_at=float(complete_at)
        j.exec_service_h=max(0.0,float(service_h))

    @staticmethod
    def _clear_execution_metadata(j:JobState):
        j.exec_started_at=None; j.exec_service_start_at=None; j.exec_complete_at=None; j.exec_service_h=0.0

    def _active_execution_end(self,j:JobState):
        """Known completion time of the *current* active execution, if any."""
        if j.status!='PROCESSING' or j.current_provider is None:
            return None
        if j.current_mode=='recovery':
            t=self.recovery_active.get(j.jid,j.exec_complete_at)
            return None if t is None else float(t)
        p=self.providers[j.current_provider]
        if p.active_job==j.jid:
            return float(p.busy_until)
        return None if j.exec_complete_at is None else float(j.exec_complete_at)

    def _remaining_active_service_h(self,j:JobState):
        """Unprocessed service portion of the current committed execution."""
        end=self._active_execution_end(j)
        if end is None or j.exec_service_start_at is None:
            return 0.0
        service_start=float(j.exec_service_start_at)
        if self.now<=service_start:
            return float(j.exec_service_h)
        return max(0.0,min(float(j.exec_service_h),end-self.now))

    def _projected_completion(self,j:JobState,pidx:Optional[int]=None,mode:Optional[str]=None):
        if pidx is None: pidx=j.current_provider
        if mode is None: mode=j.current_mode
        if pidx is None: return float('inf')
        # For an execution already in progress on the queried resource/mode, its
        # completion is known from the committed reservation.  Do not add the full
        # service time a second time on top of residual busy time.
        if j.status=='PROCESSING' and j.current_provider==pidx and j.current_mode==mode:
            end=self._active_execution_end(j)
            if end is not None:
                return end
        dur=self.service_h(j,pidx)
        switched=(j.current_provider is not None and (j.current_provider!=pidx or j.current_mode!=mode))
        transfer=self.setup_transfer_h(j,pidx) if switched else 0.0
        if mode=='recovery':
            return self.now+self.recovery_activation_h+transfer+dur
        # If the job is already queued at this provider, count only jobs ahead of it;
        # otherwise it would be appended behind the full observable queue.
        exclude=j.jid if (j.current_provider==pidx and j.jid in self.providers[pidx].queue) else None
        wait=self.provider_backlog_h(pidx,exclude_jid=exclude)
        return self.now+wait+transfer+dur

    def downstream_lb_after_current(self,j:JobState):
        rem=0.0
        for oi in range(j.op_index+1,len(j.route)):
            op=j.route[oi]; proc=self._proc_for_op(op)
            feas=list(self._feasible_for_template_op(j.template,op))
            if feas: rem += min(self.service_h(j,p) for p in feas)
        return rem

    def projected_order_completion_lb(self,j:JobState,pidx:Optional[int]=None,mode:Optional[str]=None):
        return self._projected_completion(j,pidx,mode)+self.downstream_lb_after_current(j)

    def _at_risk(self,j):
        if j.done or j.status=='PROCESSING': return False
        if j.current_provider is None: return True
        return self.projected_order_completion_lb(j)>j.due

    def _accrue_time_cost(self,new_t:float):
        if new_t<=self.now: return
        dt=new_t-self.now
        # Correct time-weighted structural telemetry. The previous Phase-A build
        # measured recovery occupancy by decision count and omitted utilization
        # from the hard PASS logic.
        # Structural load/binding is defined on the 0..H operating window in which
        # arrivals are admitted. The H..Hmax interval is a drain window and must not
        # dilute utilization/scarcity diagnostics. Completion is still evaluated at Hmax.
        struct_end=min(new_t,self.horizon)
        struct_start=min(self.now,self.horizon)
        dt_struct=max(0.0,struct_end-struct_start)
        if dt_struct>0:
            self._telemetry_elapsed += dt_struct
            if self.recovery_free < self.recovery_units:
                self._recovery_busy_time += dt_struct
            busy_recovery_units=max(0, self.recovery_units-self.recovery_free)
            self._recovery_used_unit_time += busy_recovery_units*dt_struct
            if self.recovery_units>0 and self.recovery_free<=0:
                self._recovery_full_time += dt_struct
            procs=sorted({p.machine.process for p in self.providers})
            for proc in procs:
                avail=sum(1 for p in self.providers if p.machine.process==proc and p.available)
                busy=sum(1 for p in self.providers if p.machine.process==proc and p.active_job is not None)
                self._cap_available_time[proc]=self._cap_available_time.get(proc,0.0)+avail*dt_struct
                self._cap_busy_time[proc]=self._cap_busy_time.get(proc,0.0)+busy*dt_struct
            for p in self.providers:
                if p.available:
                    self._provider_available_time[p.idx] += dt_struct
                if p.active_job is not None:
                    self._provider_busy_time[p.idx] += dt_struct
        # Update the fully observable demand regime consistently with the generator timeline.
        for tt,zz in self.regime_segments:
            if tt<=new_t: self.regime=zz
            else: break
        # exact incremental weighted tardiness for unfinished arrived jobs
        mid_start=self.now; mid_end=new_t
        for j in self.jobs.values():
            if j.arrival>self.now or j.done: continue
            late_start=max(self.now,j.due); late_end=max(late_start,new_t)
            if late_end>late_start: self.ledger.tardiness += (late_end-late_start)*(1.0+0.5*j.priority)
        self.now=new_t

    def _actions_for(self,j:JobState):
        acts=[]
        feas=self.feasible_providers(j)
        for pidx in feas:
            keep=(j.current_provider==pidx and j.current_mode=='regular')
            # A down provider may only be retained as KEEP (wait for its known recovery);
            # switching *to* a currently down regular provider is not operationally feasible.
            if self.providers[pidx].available or keep:
                acts.append(Action(pidx,'regular',keep))
            # Recovery is an external/shared emergency execution mode parameterized by the
            # provider's operation characteristics; it does not consume the regular provider.
            if self.recovery_free>0:
                acts.append(Action(pidx,'recovery',j.current_provider==pidx and j.current_mode=='recovery'))
        return acts
    def _make_decision(self,j:JobState,reason:str):
        acts=self._actions_for(j)
        if not acts: return False
        self.pending=Decision(self.now,j.jid,reason,acts,np.ones(len(acts),dtype=bool)); j.decision_pending=True
        self.trace.append(('DECISION',round(self.now,6),j.jid,reason,len(acts)))
        return True

    def _start(self,j:JobState,a:Action):
        p=self.providers[a.provider]; old=j.current_provider; oldmode=j.current_mode
        switched=(old is not None and (old!=a.provider or oldmode!=a.mode))
        # KEEP for a job already waiting in the same regular-provider queue must be
        # state preserving. Earlier builds removed and re-appended the job, silently
        # moving it to the tail of the queue. That was not a true KEEP action.
        already_queued_keep=(a.mode=='regular' and old==a.provider and oldmode=='regular' and j.jid in p.queue)
        if already_queued_keep:
            self.trace.append(('KEEP_QUEUE',self.now,j.jid,a.provider,p.queue.index(j.jid)))
            return
        if old is not None and j.jid in self.providers[old].queue:
            self.providers[old].queue.remove(j.jid)
        j.current_provider=a.provider; j.current_mode=a.mode; j.status='WAITING'; j.waiting_since=self.now
        delay=self.setup_transfer_h(j,a.provider) if switched else 0.0
        j.pending_transfer_h=delay
        if a.mode=='recovery':
            if self.recovery_free<=0: raise RuntimeError('recovery capacity violation')
            self.recovery_free-=1; j.recovery_reserved=True
            service=self.service_h(j,a.provider); nonservice=self.recovery_activation_h+delay; dur=nonservice+service
            self.ledger.switch += self.kappa*self.b.median_operation_h if switched else 0.0
            self.ledger.recovery += self.direct_cost(j,a.provider,'recovery')-self.direct_cost(j,a.provider,'regular')
            j.status='PROCESSING'; j.pending_transfer_h=0.0; j.exec_token+=1; tok=j.exec_token
            self._set_execution_metadata(j,service,nonservice,self.now+dur)
            self.recovery_active[j.jid]=self.now+dur
            self._push(self.now+dur,'COMPLETE',{'j':j.jid,'p':a.provider,'mode':'recovery','dur':dur,'token':tok})
            self.trace.append(('START_RECOVERY',self.now,j.jid,a.provider,dur)); return
        # regular provider can be queued if busy/down.
        if switched:
            self.ledger.switch += self.kappa*self.b.median_operation_h
        if p.available and p.active_job is None:
            service=self.service_h(j,a.provider); dur=service+delay
            p.active_job=j.jid; p.busy_until=self.now+dur; j.status='PROCESSING'; j.pending_transfer_h=0.0; j.exec_token+=1; tok=j.exec_token
            self._set_execution_metadata(j,service,delay,self.now+dur)
            self._push(self.now+dur,'COMPLETE',{'j':j.jid,'p':a.provider,'mode':'regular','dur':dur,'token':tok})
            self.trace.append(('START',self.now,j.jid,a.provider,dur))
        else:
            if j.jid not in p.queue: p.queue.append(j.jid)

    def _dispatch(self,pidx):
        p=self.providers[pidx]
        if not p.available or p.active_job is not None: return
        while p.queue and self.jobs[p.queue[0]].done: p.queue.pop(0)
        if not p.queue: return
        jid=p.queue.pop(0); j=self.jobs[jid]
        transfer=max(0.0,j.pending_transfer_h); service=self.service_h(j,pidx); dur=service+transfer
        p.active_job=jid; p.busy_until=self.now+dur; j.status='PROCESSING'; j.current_provider=pidx; j.current_mode='regular'; j.pending_transfer_h=0.0
        j.exec_token+=1; tok=j.exec_token
        self._set_execution_metadata(j,service,transfer,self.now+dur)
        self._push(self.now+dur,'COMPLETE',{'j':jid,'p':pidx,'mode':'regular','dur':dur,'token':tok})

    def _complete(self,x):
        j=self.jobs[x['j']]; pidx=x['p']; mode=x['mode']; dur=float(x['dur'])
        # Ignore stale completion events from an execution invalidated by failure/recomposition.
        if int(x.get('token',-1)) != j.exec_token or j.done or j.status!='PROCESSING' or j.current_provider!=pidx or j.current_mode!=mode:
            return
        # Economic service is completion-billed.  Physical processing time is
        # tracked separately so interrupted work is not silently described as billed service.
        self.ledger.service += self.direct_cost(j,pidx,'regular')
        self._completed_processing_h += float(j.exec_service_h or self.service_h(j,pidx))
        if mode=='recovery' and j.recovery_reserved:
            self.recovery_free+=1; j.recovery_reserved=False; self.recovery_active.pop(j.jid,None)
        if mode=='regular':
            p=self.providers[pidx]
            if p.active_job==j.jid: p.active_job=None; p.busy_until=self.now
        self._clear_execution_metadata(j)
        j.op_index+=1; j.interrupted=False; j.current_provider=None; j.current_mode='regular'
        if j.op_index>=len(j.route):
            j.status='COMPLETE'; j.completed_at=self.now
        else:
            j.status='READY'; self._make_decision(j,'operation-ready')
        if mode=='regular': self._dispatch(pidx)
        self._material_rechecks()

    def _fail(self,x):
        p=self.providers[x['p']]
        if not p.available: return
        p.available=False; p.fail_count+=1; p.recover_at=self.now+float(x['down'])
        if p.active_job is not None:
            j=self.jobs[p.active_job]; p.active_job=None; p.busy_until=self.now
            if not j.done and j.op_index < len(j.route):
                # Record physical work actually consumed before the interruption.  This
                # diagnostic is deliberately separate from the frozen economic restart
                # penalty and therefore does not alter the objective.
                if j.exec_service_start_at is not None:
                    used=max(0.0,self.now-float(j.exec_service_start_at))
                    self._wasted_processing_h += min(float(j.exec_service_h),used)
                j.exec_token += 1  # invalidate the already-scheduled COMPLETE event
                self._clear_execution_metadata(j)
                j.status='WAITING'; j.interrupted=True; j.current_provider=p.idx; j.current_mode='regular'
                self.ledger.restart += .15*self.service_h(j,p.idx)
                self._make_decision(j,'provider-disruption')
        self._push(p.recover_at,'RECOVER',{'p':p.idx})
        # Every queued job affected by this disruption becomes eligible for recomposition.
        # Queue explicit same-time events so one pending decision does not suppress the rest.
        for jid in list(p.queue):
            self._push(self.now,'RECOMPOSE',{'j':jid,'p':p.idx,'reason':'provider-disruption'})
    def _recover(self,x):
        p=self.providers[x['p']]; p.available=True; p.recover_at=0.0; self._dispatch(p.idx); self._material_rechecks()
    def _material_rechecks(self):
        if self.pending is not None: return
        candidates=[j for j in self.jobs.values() if j.arrival<=self.now and not j.done and j.status in ('READY','WAITING') and self._at_risk(j)]
        if candidates:
            candidates.sort(key=lambda j:(j.due,j.jid)); self._make_decision(candidates[0],'at-risk-review')

    def next_decision(self):
        if self.pending is not None: return self.pending
        while self.events and not self.done:
            t,_,_,typ,x=heapq.heappop(self.events)
            if t>self.hard_cap: self._accrue_time_cost(self.hard_cap); self._terminalize(); return None
            self._accrue_time_cost(t)
            if typ=='ARRIVAL':
                j=self.jobs[x['j']]; j.status='READY'; self._make_decision(j,'operation-ready')
            elif typ=='COMPLETE': self._complete(x)
            elif typ=='FAIL': self._fail(x)
            elif typ=='RECOVER': self._recover(x)
            elif typ=='RECOMPOSE':
                j=self.jobs.get(x['j'])
                if j is not None and not j.done and j.status in ('READY','WAITING') and j.current_provider==x.get('p'):
                    self._make_decision(j,x.get('reason','provider-disruption'))
            if self.pending is not None: return self.pending
            if self._episode_complete(): self._terminalize(); return None
        if not self.done: self._accrue_time_cost(self.hard_cap); self._terminalize()
        return None
    def _episode_complete(self):
        admitted=[j for j in self.jobs.values() if j.arrival<=self.horizon]
        return bool(admitted) and all(j.done for j in admitted)
    def residual_terminal_liability(self,j:JobState):
        """Residual economic liability at the hard cap.

        The service component follows the implemented completion-billed contract:
        an unfinished current operation still carries its full outstanding regular
        service charge, while future operations use the cheapest feasible regular
        service charge.  The time component is an *optimistic continuation time*: for
        an active operation it uses the known remaining time to its committed completion,
        not the full service time again.  Additional tardiness is due-date aware and
        excludes tardiness already accrued before the hard cap.

        This is a transparent terminal accounting surrogate, not a claim that the whole
        expression is a mathematical lower bound on every possible economic contract.
        """
        rem_time=0.0; rem_cost=0.0
        start=j.op_index
        if j.status=='PROCESSING':
            end=self._active_execution_end(j)
            if end is not None:
                rem_time += max(0.0,end-self.now)
                # The implemented service ledger bills the operation on completion, so
                # its full regular-equivalent charge is still outstanding at the cap.
                if j.current_provider is not None:
                    rem_cost += self.direct_cost(j,j.current_provider,'regular')
                start=j.op_index+1
        for oi in range(start,len(j.route)):
            op=j.route[oi]
            feas=list(self._feasible_for_template_op(j.template,op))
            if feas:
                best=min(feas,key=lambda p:self.service_h(j,p))
                rem_time += self.service_h(j,best)
                rem_cost += self.direct_cost(j,best,'regular')
        w=1.0+.5*j.priority
        already=max(0.0,self.now-j.due)
        optimistic_finish=max(0.0,self.now+rem_time-j.due)
        additional_tardiness=w*max(0.0,optimistic_finish-already)
        return rem_cost+additional_tardiness

    def residual_economic_lb(self,j:JobState):
        """Compatibility alias for pre-v13 callers; see residual_terminal_liability."""
        return self.residual_terminal_liability(j)

    def _terminalize(self):
        if self.done: return
        for j in self.jobs.values():
            if j.arrival<=self.horizon and not j.done:
                self.ledger.terminal += self.residual_terminal_liability(j)
        self.done=True; self.pending=None

    def step(self,action_idx:int, shaped:bool=True):
        d=self.pending
        if d is None: raise RuntimeError('no pending decision')
        if action_idx<0 or action_idx>=len(d.actions) or not d.mask[action_idx]: raise RuntimeError('invalid/masked action')
        j=self.jobs[d.job_id]; before=self.ledger.total(); phi0=self.potential()
        a=d.actions[action_idx]; j.decision_pending=False; self.pending=None; self._start(j,a)
        nxt=self.next_decision(); true_delta=self.ledger.total()-before; true_reward=-true_delta/self.cost_ref
        phi1=0.0 if self.done else self.potential(); reward=true_reward+(phi1-phi0 if shaped else 0.0)
        return nxt,float(reward),float(true_delta),self.done

    @property
    def cost_ref(self): return max(1.0,10*self.b.median_operation_h)
    def potential(self):
        lb=0.0
        for j in self.jobs.values():
            if j.arrival>self.now or j.done: continue
            rem=0.0
            for oi in range(j.op_index,len(j.route)):
                op=j.route[oi]; proc='P2' if op=='P2b' else op
                feas=list(self._feasible_for_template_op(j.template,op))
                if feas: rem += min(self.service_h(j,p) for p in feas)
            lb += rem + (1+.5*j.priority)*max(0.0,self.now+rem-j.due)
        return -lb/self.cost_ref

    def metrics(self):
        admitted=[j for j in self.jobs.values() if j.arrival<=self.horizon]
        comp=[j for j in admitted if j.done]
        return {'arrived':len(admitted),'completed':len(comp),'completion_fraction':len(comp)/max(1,len(admitted)),
                'cost_total':self.ledger.total(),'cost_per_arrived':self.ledger.total()/max(1,len(admitted)),
                'recovery_free':self.recovery_free,'ledger':self.ledger.dict(),'time':self.now,
                'processing_completed_h':float(self._completed_processing_h),
                'processing_wasted_h':float(self._wasted_processing_h)}

    def shared_recovery_release_summary(self):
        """Earliest/mean release of the *shared recovery capacity* only.

        Regular-provider repair ETA is represented separately in provider features.
        """
        rem=[max(0.0,t-self.now) for t in self.recovery_active.values() if t>self.now]
        return (min(rem) if rem else 0.0, float(np.mean(rem)) if rem else 0.0)

    def recovery_release_summary(self):
        """Compatibility alias; see shared_recovery_release_summary."""
        return self.shared_recovery_release_summary()

    def calibration_eligibility_criticality(self):
        """Normalized calibration-only eligibility-share prior.

        Each calibration operation contributes 1/|F| to every feasible provider in F.
        No arrival-rate, service-speed, or workload-volume term enters this static prior.
        """
        # Cache because the quantity is invariant within and across episode decisions.
        if self._static_criticality_cache is None:
            scores=np.zeros(len(self.providers),float)
            cal=[self.b.order_by_id(i) for i in self.b.calibration_ids]
            for j in cal:
                for op in j.route:
                    feas=self._feasible_for_template_op(j,op)
                    if feas:
                        for p in feas: scores[p]+=1.0/len(feas)
            self._static_criticality_cache=scores/(scores.sum()+1e-9)
        return self._static_criticality_cache

    def static_criticality(self):
        """Compatibility name retained for frozen checkpoints; exact semantics above."""
        return self.calibration_eligibility_criticality()

    def structural_telemetry(self):
        utils={}
        for proc,den in self._cap_available_time.items():
            utils[proc]=self._cap_busy_time.get(proc,0.0)/max(1e-9,den)
        putils={
            int(i): self._provider_busy_time.get(i,0.0)/max(1e-9,self._provider_available_time.get(i,0.0))
            for i in self._provider_available_time
        }
        return {
            'elapsed_h': float(self._telemetry_elapsed),
            'recovery_binding_time_fraction': float(
                self._recovery_busy_time/max(1e-9,self._telemetry_elapsed)
            ),
            'recovery_any_use_time_fraction': float(
                self._recovery_busy_time/max(1e-9,self._telemetry_elapsed)
            ),
            'recovery_utilization_fraction': float(
                self._recovery_used_unit_time/max(1e-9,self._telemetry_elapsed*max(1,self.recovery_units))
            ) if self.recovery_units>0 else 0.0,
            'recovery_full_capacity_time_fraction': float(
                self._recovery_full_time/max(1e-9,self._telemetry_elapsed)
            ) if self.recovery_units>0 else 0.0,
            'capability_utilization_time_weighted': {
                k:float(v) for k,v in utils.items()
            },
            'bottleneck_capability_utilization': float(
                max(utils.values()) if utils else 0.0
            ),
            'provider_utilization_time_weighted': {str(k):float(v) for k,v in putils.items()},
            'critical_provider_utilization': float(max(putils.values()) if putils else 0.0),
        }

    # ---------- state features ----------
    def lower_bound_remaining(self,j:JobState):
        """Optimistic wall-clock time to finish the job from the current state."""
        rem=0.0; start=j.op_index
        if j.status=='PROCESSING':
            end=self._active_execution_end(j)
            if end is not None:
                rem += max(0.0,end-self.now)
                start=j.op_index+1
        for oi in range(start,len(j.route)):
            op=j.route[oi]
            feas=list(self._feasible_for_template_op(j.template,op))
            if feas: rem += min(self.service_h(j,p) for p in feas)
        return rem
    def capability_pressure(self):
        classes=self.b.process_classes
        physical=('P1','P2','P3','P4','P5')
        ready_phys={k:0.0 for k in physical}; pipe_phys={k:0.0 for k in physical}
        caps={k:sum(1.0 for p in self.providers if p.machine.process==k and p.available) for k in physical}
        for j in self.jobs.values():
            if j.arrival>self.now or j.done: continue
            for oi in range(j.op_index,len(j.route)):
                op=j.route[oi]; proc=self._proc_for_op(op)
                feas=list(self._feasible_for_template_op(j.template,op))
                if not feas: continue
                w=min(self.service_h(j,p) for p in feas); pipe_phys[proc]+=w
                if oi==j.op_index and j.status!='PROCESSING': ready_phys[proc]+=w
        out={}
        for k in classes:
            proc=self._proc_for_op(k)
            out[k]=(ready_phys[proc]/max(1e-6,caps[proc]),pipe_phys[proc]/max(1e-6,caps[proc]))
        return out
    def criticality(self):
        # Dynamic scarcity score based on currently known remaining routes plus calibration capability mix.
        scores=np.zeros(len(self.providers),float)
        for j in self.jobs.values():
            if j.arrival>self.now or j.done: continue
            for oi in range(j.op_index,len(j.route)):
                op=j.route[oi]; proc='P2' if op=='P2b' else op
                feas=list(self._feasible_for_template_op(j.template,op))
                if feas:
                    for p in feas: scores[p]+=1.0/len(feas)
        s=scores.sum()
        return scores/(s+1e-9)
