from __future__ import annotations
import numpy as np

PROTECTED_FINAL_RANGES=((900001,900050),(910001,910030),(920001,920050),(940001,940030))

def aggregate_training_checkpoints(cost_matrix):
    """Equal-weight mean across the five frozen training checkpoints per paired evaluation unit."""
    x=np.asarray(cost_matrix,dtype=float)
    if x.ndim!=2 or x.shape[1]!=5:
        raise ValueError('expected shape (n_evaluation_units, 5 training checkpoints)')
    if not np.isfinite(x).all():
        raise ValueError('non-finite final-evaluation input')
    return x.mean(axis=1)

def paired_effect(a,b):
    """Signed effect a-b; negative means method a has lower economic cost/order."""
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    if a.shape!=b.shape or a.ndim!=1 or a.size==0:
        raise ValueError('paired 1-D arrays of equal nonzero length required')
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        raise ValueError('non-finite values')
    d=a-b
    pct=np.where(b!=0.0,100.0*d/b,np.nan)
    return {'mean_absolute_difference':float(d.mean()),
            'mean_percent_difference':float(np.nanmean(pct)),
            'n':int(d.size)}

def paired_bootstrap_mean_difference(a,b,resamples=10000,seed=730001,confidence=0.95):
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    if a.shape!=b.shape or a.ndim!=1 or a.size==0:
        raise ValueError('paired 1-D arrays of equal nonzero length required')
    d=a-b
    if not np.isfinite(d).all(): raise ValueError('non-finite values')
    rng=np.random.default_rng(int(seed)); n=d.size
    idx=rng.integers(0,n,size=(int(resamples),n))
    boots=d[idx].mean(axis=1)
    alpha=1.0-float(confidence)
    lo,hi=np.quantile(boots,[alpha/2,1-alpha/2])
    return {'estimate':float(d.mean()),'ci_low':float(lo),'ci_high':float(hi),
            'confidence':float(confidence),'resamples':int(resamples),'seed':int(seed)}

def paired_signflip_pvalue(a,b,resamples=100000,seed=730002):
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    if a.shape!=b.shape or a.ndim!=1 or a.size==0:
        raise ValueError('paired 1-D arrays of equal nonzero length required')
    d=a-b
    if not np.isfinite(d).all(): raise ValueError('non-finite values')
    obs=abs(float(d.mean())); rng=np.random.default_rng(int(seed)); n=d.size
    # Chunked to avoid large memory use.
    exceed=0; done=0; total=int(resamples)
    while done<total:
        m=min(10000,total-done)
        signs=rng.choice(np.array([-1.0,1.0]),size=(m,n))
        stats=np.abs((signs*d).mean(axis=1))
        exceed += int(np.count_nonzero(stats>=obs-1e-15)); done += m
    return float((exceed+1)/(total+1))

def holm_adjust(pvalues):
    p=np.asarray(pvalues,dtype=float)
    if p.ndim!=1 or p.size==0 or np.any((p<0)|(p>1)|~np.isfinite(p)):
        raise ValueError('finite p-values in [0,1] required')
    order=np.argsort(p); m=p.size; out=np.empty(m,dtype=float); running=0.0
    for rank,idx in enumerate(order):
        val=(m-rank)*p[idx]; running=max(running,val); out[idx]=min(1.0,running)
    return out
