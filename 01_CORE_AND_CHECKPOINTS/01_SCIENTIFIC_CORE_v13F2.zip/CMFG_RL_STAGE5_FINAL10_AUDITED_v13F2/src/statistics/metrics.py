from __future__ import annotations
import numpy as np
from scipy.stats import ks_2samp

def rel_err(sim, emp):
    if emp==0: return 0.0 if sim==0 else float('inf')
    return abs(sim-emp)/abs(emp)

def ks_like(a,b):
    if len(a)==0 or len(b)==0: return float('nan')
    return float(ks_2samp(a,b).statistic)
