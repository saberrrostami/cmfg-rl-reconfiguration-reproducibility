from __future__ import annotations
import json, os, random, tempfile, shutil, time
from pathlib import Path
import numpy as np, torch
from .env import FinalDesignEnv
from .obs import ObsBuilder,ObsSpec
from .rl import PPO,PPOConfig,D3QN,D3QNConfig
from .baselines import select_b3

VALIDATION_SEEDS=(70001,70002,70003,70004,70005,70006,70007,70008)
PROBE_SEEDS=(71001,71002,71003,71004,71005,71006,71007,71008)
TARGET_RHO=.80
TARGET_RECOVERY_UNITS=1
TARGET_RECOVERY_ACTIVATION_H=.10
TARGET_FAILURE_MTBF_H=120.0
TARGET_RECOVERY_MEAN_H=.35
PPO_SCIENTIFIC_BUDGET=800_000
D3QN_SCIENTIFIC_BUDGET=400_000


def _builder(b):return ObsBuilder(ObsSpec(),b.calibration_slack_scale_h,b.median_operation_h)


def _seed_all(seed:int):
    random.seed(int(seed)); np.random.seed(int(seed)%(2**32-1)); torch.manual_seed(int(seed))
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(int(seed))
    else:
        try: torch.set_num_threads(1)
        except RuntimeError: pass
        try: torch.set_num_interop_threads(1)
        except RuntimeError: pass


def _env(b,seed,split='calibration',rho=TARGET_RHO,recovery_units=TARGET_RECOVERY_UNITS):
    return FinalDesignEnv(
        b,int(seed),rho=rho,recovery_units=recovery_units,
        recovery_activation_h=TARGET_RECOVERY_ACTIVATION_H,
        failure_mtbf_h=TARGET_FAILURE_MTBF_H,recovery_mean_h=TARGET_RECOVERY_MEAN_H,
        demand_volatility='moderate',split=split)


def _iqr(xs):
    q=np.quantile(np.asarray(xs,dtype=float),[.25,.75]); return float(q[1]-q[0])


def evaluate_agent(agent,b,algo='ppo',rho=TARGET_RHO,recovery_units=TARGET_RECOVERY_UNITS,seeds=VALIDATION_SEEDS):
    """Deterministic development evaluation on a frozen seed bank."""
    ob=_builder(b); envs=[_env(b,s,'validation',rho,recovery_units) for s in seeds]
    ds=[e.next_decision() for e in envs]; costs=[None]*len(envs)
    while any(x is not None for x in ds):
        idx=[i for i,d in enumerate(ds) if d is not None]
        obs=[ob.build(envs[i],ds[i]) for i in idx]
        acts=agent.act_batch(obs,det=True)[0] if algo=='ppo' else agent.greedy_batch(obs)
        for ii,a in zip(idx,acts):
            nd,_,_,_=envs[ii].step(int(a),shaped=False); ds[ii]=nd
            if nd is None and envs[ii].done: costs[ii]=envs[ii].metrics()['cost_per_arrived']
    for i,e in enumerate(envs):
        if costs[i] is None: costs[i]=e.metrics()['cost_per_arrived']
    med=float(np.median(costs)); iqr=_iqr(costs); score=med+.25*iqr
    return {'median_cost':med,'iqr_cost':iqr,'robust_score':float(score),'costs':[float(x) for x in costs],'validation_seeds':list(seeds)}


def build_fixed_probe_bank(b,rho=TARGET_RHO,recovery_units=TARGET_RECOVERY_UNITS,seeds=PROBE_SEEDS,max_obs=160):
    """Policy-independent state bank for numerical/collapse diagnostics only."""
    ob=_builder(b); out=[]
    for s in seeds:
        e=_env(b,s,'calibration',rho,recovery_units); d=e.next_decision()
        while d is not None and not e.done and len(out)<max_obs:
            out.append(ob.build(e,d).copy())
            d,_,_,_=e.step(select_b3(e,d),shaped=False)
        if len(out)>=max_obs: break
    if not out: raise RuntimeError('fixed probe bank is empty')
    return out


def _save_ckpt(path,agent,algo,step,extra):
    state={'algo':algo,'step':int(step),'model':(agent.net.state_dict() if algo=='ppo' else agent.online.state_dict()),
           'optimizer':agent.opt.state_dict(),'extra':extra,'numpy_rng':np.random.get_state(),
           'python_rng':random.getstate(),'torch_rng':torch.get_rng_state()}
    if torch.cuda.is_available(): state['torch_cuda_rng']=torch.cuda.get_rng_state_all()
    torch.save(state,path)


def _restore_common_rng(z):
    if 'numpy_rng' in z: np.random.set_state(z['numpy_rng'])
    if 'python_rng' in z: random.setstate(z['python_rng'])
    if 'torch_rng' in z: torch.set_rng_state(z['torch_rng'])
    if torch.cuda.is_available() and 'torch_cuda_rng' in z: torch.cuda.set_rng_state_all(z['torch_cuda_rng'])


def _model_finite(module): return all(bool(torch.isfinite(p).all().item()) for p in module.parameters())


def _probe_diagnostics(agent,probe_bank):
    probs=agent.action_probs(probe_bank); finite=bool(np.isfinite(probs).all())
    if not finite:
        return {'finite':False,'mean_normalized_entropy':float('nan'),'dominant_slot_fraction':1.0,'collapse_suspected':True}
    valid=np.asarray([o.action_mask.sum() for o in probe_bank],dtype=float); ent=[]
    for row,k in zip(probs,valid):
        q=row[row>0]; h=-float(np.sum(q*np.log(q+1e-12))); ent.append(h/max(1e-12,np.log(max(2.0,k))))
    sel=np.argmax(probs,axis=1); counts=np.bincount(sel,minlength=probs.shape[1]); dom=float(counts.max()/max(1,len(sel)))
    mean_ent=float(np.mean(ent)) if ent else 0.0
    return {'finite':True,'mean_normalized_entropy':mean_ent,'dominant_slot_fraction':dom,
            'collapse_suspected':bool(np.mean(valid)>=3.0 and dom>=.999 and mean_ent<1e-6)}


def _eta_line(prefix,seed,total,maxT,start):
    elapsed=max(1e-9,time.perf_counter()-start); rate=total/elapsed; remain=max(0,maxT-total)/max(1e-9,rate)
    print(f'{prefix}_HEARTBEAT seed={seed} step={total} rate={rate:.1f}_transitions_per_s eta_h={remain/3600:.2f}',flush=True)


def train_ppo(b,seed,out_dir,rho=TARGET_RHO,recovery_units=TARGET_RECOVERY_UNITS,resume=False,smoke=False,max_steps_override=None,checkpoint_steps_override=None,selection_steps_override=None,anneal_transitions_override=None,n_envs_override=None):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True); _seed_all(seed)
    maxT=int(max_steps_override) if max_steps_override is not None else (20_000 if smoke else PPO_SCIENTIFIC_BUDGET)
    annealT=int(anneal_transitions_override) if anneal_transitions_override is not None else (20_000 if smoke else PPO_SCIENTIFIC_BUDGET)
    device='cuda' if torch.cuda.is_available() else 'cpu'; cfg=PPOConfig(anneal_transitions=annealT)
    agent=PPO(ObsSpec(),cfg,device); ob=_builder(b); probe_bank=build_fixed_probe_bank(b,rho,recovery_units,max_obs=(32 if smoke else 160))
    thresholds=([maxT] if smoke else (list(map(int,checkpoint_steps_override)) if checkpoint_steps_override is not None else [600_000,700_000,800_000]))
    selection_steps=([maxT] if smoke else (list(map(int,selection_steps_override)) if selection_steps_override is not None else [600_000,700_000,800_000]))
    if not thresholds or thresholds[-1] != maxT or any(x<=0 or x>maxT for x in thresholds) or thresholds != sorted(set(thresholds)):
        raise ValueError('checkpoint_steps_override must be unique increasing positive steps ending at maxT')
    if not selection_steps or any(x not in thresholds for x in selection_steps) or selection_steps != sorted(set(selection_steps)):
        raise ValueError('selection_steps_override must be a unique increasing subset of diagnostic checkpoint steps')
    n_envs=int(n_envs_override) if n_envs_override is not None else (2 if smoke else 8)
    total=0; hist=[]; recover=out/'PPO_RECOVERY.pt'; next_ep=0; start=time.perf_counter(); last_hb=0
    if resume and recover.exists():
        z=torch.load(recover,map_location=device);agent.net.load_state_dict(z['model']);agent.opt.load_state_dict(z['optimizer']);total=int(z['step']);hist=z['extra'].get('history',[]);next_ep=int(z['extra'].get('next_episode_index',0));_restore_common_rng(z)
    envs=[];ds=[]
    for _ in range(n_envs):
        e=_env(b,int(seed*100000+next_ep),'calibration',rho,recovery_units);next_ep+=1;envs.append(e);ds.append(e.next_decision())
    seen={int(h['threshold']) for h in hist if 'threshold' in h}
    while total<maxT:
        pending=[x for x in thresholds if x>total and x not in seen]
        next_stop=min(pending) if pending else maxT
        target=min(cfg.rollout,maxT-total,next_stop-total); collected=0;by_env=[[] for _ in range(n_envs)]
        while collected<target:
            for i in range(n_envs):
                if ds[i] is None and envs[i].done:
                    envs[i]=_env(b,int(seed*100000+next_ep),'calibration',rho,recovery_units);next_ep+=1;ds[i]=envs[i].next_decision()
                elif ds[i] is None: ds[i]=envs[i].next_decision()
            idx=[i for i,d in enumerate(ds) if d is not None]
            if not idx: raise RuntimeError('PPO vector rollout has no active environment')
            rem=target-collected
            if len(idx)>rem: idx=idx[:rem]
            obs=[ob.build(envs[i],ds[i]) for i in idx]; acts,logps,vals,_=agent.act_batch(obs,det=False)
            stepped=[];next_obs=[];next_map=[]
            for loc,i in enumerate(idx):
                nd,r,_,done=envs[i].step(int(acts[loc]),shaped=True); no=None if nd is None else ob.build(envs[i],nd);ds[i]=nd
                stepped.append((i,obs[loc],int(acts[loc]),float(logps[loc]),float(vals[loc]),float(r),bool(done),no))
                if no is not None:next_map.append(len(stepped)-1);next_obs.append(no)
            nv=agent.value_batch(next_obs);nv_by={k:float(v) for k,v in zip(next_map,nv)}
            for k,(i,o,a,lp,v,r,done,no) in enumerate(stepped):
                by_env[i].append({'o':o,'a':a,'logp':lp,'v':v,'r':r,'nv':0.0 if no is None else nv_by[k],'done':done});total+=1;collected+=1
        roll=[]
        for traj in by_env:
            gae=0.;items=[]
            for x in reversed(traj):
                delta=x['r']+cfg.gamma*x['nv']*(1-x['done'])-x['v'];gae=delta+cfg.gamma*cfg.gae_lambda*(1-x['done'])*gae;items.append((gae,gae+x['v']))
            for x,(aa,ret) in zip(traj,reversed(items)):x['adv']=aa;x['ret']=ret;roll.append(x)
        metrics=agent.update(roll,min(1.,total/max(1,cfg.anneal_transitions)))
        if not _model_finite(agent.net):raise FloatingPointError('PPO non-finite parameter detected')
        if total-last_hb>=100_000 or total==maxT:_eta_line('PPO',seed,total,maxT,start);last_hb=total
        if total in thresholds and total not in seen:
            ev=evaluate_agent(agent,b,'ppo',rho,recovery_units);pdiag=_probe_diagnostics(agent,probe_bank)
            numerical_ok=bool(np.isfinite(ev['robust_score']) and pdiag['finite'] and _model_finite(agent.net))
            rec={'threshold':total,'step':total,**ev,'numerical_ok':numerical_ok,**pdiag,'update_metrics':metrics}
            hist.append(rec);seen.add(total)
            ck=out/f'PPO_seed_{seed}_STEP_{total}.pt';_save_ckpt(ck,agent,'ppo',total,{'history':hist,'next_episode_index':next_ep,'n_envs':n_envs})
            _save_ckpt(recover,agent,'ppo',total,{'history':hist,'next_episode_index':next_ep,'n_envs':n_envs})
            print(f"PPO_VALIDATION seed={seed} step={total} median={ev['median_cost']:.6f} iqr={ev['iqr_cost']:.6f} score={ev['robust_score']:.6f} finite={numerical_ok}",flush=True)
    eligible=[h for h in hist if int(h.get('step',-1)) in selection_steps and h.get('numerical_ok') and not h.get('collapse_suspected',False)]
    if not eligible: raise RuntimeError('PPO has no eligible development checkpoint')
    selected=min(eligible,key=lambda h:(h['robust_score'],h['median_cost'],h['step']))
    sel_ck=out/f"PPO_seed_{seed}_STEP_{selected['step']}.pt"; z=torch.load(sel_ck,map_location=device,weights_only=False);agent.net.load_state_dict(z['model']);agent.opt.load_state_dict(z['optimizer'])
    final=out/f'PPO_seed_{seed}_SELECTED.pt';_save_ckpt(final,agent,'ppo',selected['step'],{'history':hist,'selected_step':selected['step'],'selection_rule':'median+0.25*IQR'})
    adequate=bool(total>=maxT and all(bool(h.get('numerical_ok')) for h in hist) and not selected.get('collapse_suspected',False))
    report={'seed':seed,'steps_trained':total,'training_adequate':adequate,'completed_budget_and_numerically_valid':adequate,'numerical_ok':adequate,'history':hist,
            'selected_step':selected['step'],'selected_validation_median_cost':selected['median_cost'],'selected_validation_iqr':selected['iqr_cost'],
            'selected_robust_score':selected['robust_score'],'selected_validation_costs':selected['costs'],'selection_rule':'median+0.25*IQR',
            'final_checkpoint':final.name,'device':device,'validation_seeds':list(VALIDATION_SEEDS),'probe_seeds':list(PROBE_SEEDS),
            'target_rho':rho,'recovery_units':recovery_units,'recovery_activation_h':TARGET_RECOVERY_ACTIVATION_H,
            'failure_mtbf_h':TARGET_FAILURE_MTBF_H,'repair_mean_h':TARGET_RECOVERY_MEAN_H,'ppo_budget':maxT,'diagnostic_validation_steps':list(map(int,thresholds)),'selection_steps':list(map(int,selection_steps)),'checkpoint_steps':list(map(int,selection_steps)),'anneal_transitions':annealT,'vector_envs':n_envs,
            'obs_revision':'v2.1.2_ctmc_forecast_queue_horizon_context','architecture_revision':'v2.1.3_explicit_focal_context'}
    (out/f'PPO_seed_{seed}_REPORT.json').write_text(json.dumps(report,indent=2));return report


def train_d3qn(b,seed,out_dir,rho=TARGET_RHO,recovery_units=TARGET_RECOVERY_UNITS,resume=False,smoke=False,max_steps_override=None):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True);_seed_all(seed);device='cuda' if torch.cuda.is_available() else 'cpu'
    cfg=(D3QNConfig(replay=5000,batch=64,target_update=100,warmup=128,update_every=16) if smoke else D3QNConfig(replay=100000,warmup=5000))
    if smoke: replay_dir=None
    else:
        replay_base=(Path('/content')/'cmfg_d3qn_replay') if Path('/content').exists() else out.parent/'_cmfg_d3qn_replay';replay_base.mkdir(parents=True,exist_ok=True)
        replay_dir=tempfile.mkdtemp(prefix=f'cmfg_d3qn_{seed}_',dir=str(replay_base));free_gb=shutil.disk_usage(replay_base).free/(1024**3)
        print(f'D3QN_INIT seed={seed} device={device} replay_capacity={cfg.replay} replay_dir={replay_dir} free_disk_gb={free_gb:.2f}',flush=True)
    agent=D3QN(ObsSpec(),cfg,seed,device,replay_backing_dir=replay_dir)
    if not smoke:print('D3QN_REPLAY_READY backend=local_memmap_on_content',flush=True)
    ob=_builder(b);rng=np.random.default_rng(seed);maxT=int(max_steps_override) if max_steps_override is not None else (20_000 if smoke else D3QN_SCIENTIFIC_BUDGET)
    thresholds=([maxT] if smoke else [200_000,300_000,400_000]);total=0;ep=0;hist=[];start=time.perf_counter();last_hb=0
    while total<maxT:
        e=_env(b,int(seed*100000+ep),'calibration',rho,recovery_units);d=e.next_decision()
        while d is not None and not e.done and total<maxT:
            o=ob.build(e,d);decay=min(1.0,total/max(1,maxT));eps=max(cfg.eps_final,1-(1-cfg.eps_final)*decay);a=agent.act(o,eps,rng)
            nd,r,_,done=e.step(a,shaped=True);no=None if nd is None else ob.build(e,nd);agent.replay.add(o,a,r,no,done)
            if total%cfg.update_every==0:
                agent.update()
                if not _model_finite(agent.online):raise FloatingPointError('D3QN non-finite parameter detected')
            total+=1;d=nd
            if total-last_hb>=100_000 or total==maxT:_eta_line('D3QN',seed,total,maxT,start);last_hb=total
            if total in thresholds:
                ev=evaluate_agent(agent,b,'d3qn',rho,recovery_units);numerical_ok=bool(np.isfinite(ev['robust_score']) and _model_finite(agent.online))
                hist.append({'step':total,**ev,'epsilon':float(eps),'numerical_ok':numerical_ok});print(f"D3QN_VALIDATION seed={seed} step={total} median={ev['median_cost']:.6f} score={ev['robust_score']:.6f} finite={numerical_ok}",flush=True)
        ep+=1
    ev=evaluate_agent(agent,b,'d3qn',rho,recovery_units);adequate=bool(total>=maxT and _model_finite(agent.online) and np.isfinite(ev['median_cost']))
    final=out/f'D3QN_seed_{seed}_FINAL.pt';torch.save({'model':agent.online.state_dict(),'step':total,'seed':seed},final)
    report={'seed':seed,'steps':total,'training_adequate':adequate,'completed_budget_and_numerically_valid':adequate,'numerical_ok':adequate,'validation_median_cost':ev['median_cost'],
            'validation_iqr':ev['iqr_cost'],'validation_robust_score':ev['robust_score'],'history':hist,'final_checkpoint':final.name,'device':device,
            'validation_seeds':list(VALIDATION_SEEDS),'target_rho':rho,'recovery_units':recovery_units,'recovery_activation_h':TARGET_RECOVERY_ACTIVATION_H,
            'replay_capacity':cfg.replay,'replay_backend':('memory' if smoke else 'local_memmap'),'replay_dtype':'float32','budget':maxT,
            'obs_revision':'v2.1.2_ctmc_forecast_queue_horizon_context','architecture_revision':'v2.1.3_explicit_focal_context'}
    (out/f'D3QN_seed_{seed}_REPORT.json').write_text(json.dumps(report,indent=2))
    if replay_dir is not None:
        try:del agent.replay;shutil.rmtree(replay_dir,ignore_errors=True)
        except Exception:pass
    return report
