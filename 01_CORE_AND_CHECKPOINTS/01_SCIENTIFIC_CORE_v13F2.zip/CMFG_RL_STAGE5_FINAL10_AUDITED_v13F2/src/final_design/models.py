from __future__ import annotations
import torch
from torch import nn
from .obs import ObsSpec
NEG=-1e9

def orth_init(m,gain=1.0):
    if isinstance(m,nn.Linear):
        nn.init.orthogonal_(m.weight,gain); nn.init.constant_(m.bias,0.)

class SetEncoder(nn.Module):
    def __init__(self,inp,emb=64):
        super().__init__(); self.net=nn.Sequential(nn.Linear(inp,64),nn.LayerNorm(64),nn.Tanh(),nn.Linear(64,emb),nn.Tanh()); self.apply(orth_init)
    def forward(self,x,mask):
        e=self.net(x); m=mask.unsqueeze(-1)
        mean=(e*m).sum(1)/m.sum(1).clamp_min(1)
        masked=e.masked_fill(~m,-1e9); mx=masked.amax(1)
        any_valid=mask.any(1,keepdim=True)
        mx=torch.where(any_valid,mx,torch.zeros_like(mx))
        return torch.cat([mean,mx],-1)

class ActorCritic(nn.Module):
    """Separate actor/critic encoders reduce gradient interference while retaining a small network."""
    def __init__(self,s:ObsSpec):
        super().__init__()
        self.aje=SetEncoder(s.job_dim); self.ape=SetEncoder(s.provider_dim)
        self.cje=SetEncoder(s.job_dim); self.cpe=SetEncoder(s.provider_dim)
        # The formal SMDP state contains X_focal separately from the unordered active-job set.
        # Row 0 of the observation is reserved for the focal job; encode it explicitly so
        # mean/max set pooling cannot alias the decision target with the rest of the WIP.
        self.afe=nn.Sequential(nn.Linear(s.job_dim,64),nn.LayerNorm(64),nn.Tanh())
        self.cfe=nn.Sequential(nn.Linear(s.job_dim,64),nn.LayerNorm(64),nn.Tanh())
        self.ce=nn.Sequential(nn.Linear(s.candidate_dim,64),nn.LayerNorm(64),nn.Tanh())
        ctx=128+128+64+s.global_dim
        self.actor=nn.Sequential(nn.Linear(ctx+64,128),nn.Tanh(),nn.Linear(128,64),nn.Tanh(),nn.Linear(64,1))
        self.critic=nn.Sequential(nn.Linear(ctx,128),nn.Tanh(),nn.Linear(128,64),nn.Tanh(),nn.Linear(64,1))
        self.apply(orth_init); nn.init.orthogonal_(self.actor[-1].weight,.01); nn.init.orthogonal_(self.critic[-1].weight,1.0)
    def forward(self,b):
        focal=b['jobs'][:,0,:]
        aj=self.aje(b['jobs'],b['job_mask']); ap=self.ape(b['providers'],b['provider_mask']); af=self.afe(focal); actx=torch.cat([af,aj,ap,b['global']],-1)
        cj=self.cje(b['jobs'],b['job_mask']); cp=self.cpe(b['providers'],b['provider_mask']); cf=self.cfe(focal); cctx=torch.cat([cf,cj,cp,b['global']],-1)
        ce=self.ce(b['candidates']); cc=actx[:,None,:].expand(-1,ce.shape[1],-1)
        logits=self.actor(torch.cat([cc,ce],-1)).squeeze(-1).masked_fill(~b['action_mask'],NEG)
        v=self.critic(cctx).squeeze(-1)
        return logits,v

class DuelingQ(nn.Module):
    def __init__(self,s:ObsSpec):
        super().__init__(); self.je=SetEncoder(s.job_dim); self.pe=SetEncoder(s.provider_dim); self.fe=nn.Sequential(nn.Linear(s.job_dim,64),nn.LayerNorm(64),nn.Tanh()); self.ce=nn.Sequential(nn.Linear(s.candidate_dim,64),nn.LayerNorm(64),nn.Tanh())
        ctx=128+128+64+s.global_dim
        self.value=nn.Sequential(nn.Linear(ctx,128),nn.Tanh(),nn.Linear(128,1)); self.adv=nn.Sequential(nn.Linear(ctx+64,128),nn.Tanh(),nn.Linear(128,64),nn.Tanh(),nn.Linear(64,1)); self.apply(orth_init)
    def forward(self,b):
        focal=b['jobs'][:,0,:]; jc=self.je(b['jobs'],b['job_mask']); pc=self.pe(b['providers'],b['provider_mask']); fc=self.fe(focal); ctx=torch.cat([fc,jc,pc,b['global']],-1); ce=self.ce(b['candidates']); cc=ctx[:,None,:].expand(-1,ce.shape[1],-1)
        a=self.adv(torch.cat([cc,ce],-1)).squeeze(-1); m=b['action_mask']; a_valid=a.masked_fill(~m,0); mean=a_valid.sum(-1,keepdim=True)/m.sum(-1,keepdim=True).clamp_min(1); q=self.value(ctx)+a-mean; return q.masked_fill(~m,NEG)
