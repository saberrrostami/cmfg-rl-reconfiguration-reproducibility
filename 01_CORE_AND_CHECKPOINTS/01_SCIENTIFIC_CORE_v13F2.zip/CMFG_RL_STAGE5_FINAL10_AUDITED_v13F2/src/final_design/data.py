from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple
import json, math
import numpy as np
import pandas as pd

TIME_SCALE = 0.007407407407407408
P25_VOL = 0.3076923076923077
P75_VOL = 0.614451804788759

PROCESS_BY_MACHINE_PREFIX = {
    'Printing':'P1', 'Drylaminasi':'P2', 'Extrusion':'P3', 'Sliting':'P4', 'Bag Making':'P5'
}

@dataclass(frozen=True)
class MachineTemplate:
    machine_id: int
    code: str
    name: str
    process: str
    min_speed: float
    ratio_speed: float
    setup_min: float
    color_limit: int | None

@dataclass(frozen=True)
class ProductTemplate:
    product_type: int
    width_class: int
    colors: int
    route_id: int
    route: Tuple[str,...]

@dataclass(frozen=True)
class OrderTemplate:
    order_id: int
    priority: int
    product_type: int
    running_meter: float
    in_date: str
    deadline: str
    arrival_h: float
    due_h: float
    route: Tuple[str,...]
    width_class: int
    colors: int

@dataclass
class EmpiricalBackbone:
    machines: List[MachineTemplate]
    products: Dict[int,ProductTemplate]
    orders: List[OrderTemplate]
    calibration_ids: List[int]
    validation_ids: List[int]
    heldout_ids: List[int]
    process_classes: Tuple[str,...]
    median_operation_h: float
    calibration_slack_scale_h: float
    base_arrival_rate_per_h: float

    def order_by_id(self, oid:int)->OrderTemplate:
        return next(o for o in self.orders if o.order_id==oid)


def _machine_process(name: str) -> str:
    for k,v in PROCESS_BY_MACHINE_PREFIX.items():
        if str(name).startswith(k): return v
    raise ValueError(f'Unmapped machine name: {name}')


def load_backbone(root: str | Path) -> EmpiricalBackbone:
    root=Path(root)
    mdf=pd.read_excel(root/'1-Machine.xlsx',header=1)
    machines=[]
    for _,r in mdf.iterrows():
        machines.append(MachineTemplate(int(r['No']),str(r['Code']),str(r['Machine Name']),_machine_process(str(r['Machine Name'])),
            float(r['MinSpeed']),float(r['Ratio Speed']),float(r['SetupTime']),None if pd.isna(r['Color']) else int(r['Color'])))
    rdf=pd.read_excel(root/'3-Routing.xlsx',header=1)
    routes={int(r['No']):tuple(str(r['Routing']).split('-')) for _,r in rdf.iterrows()}
    pdf=pd.read_excel(root/'5-Product Type.xlsx',header=1)
    products={}
    for _,r in pdf.iterrows():
        rid=int(r['Routing']); pid=int(r['No'])
        products[pid]=ProductTemplate(pid,int(r['Lebar Bahan']),int(r['Jumlah Warna']),rid,routes[rid])
    odf=pd.read_excel(root/'6-Data Order.xlsx',header=1)
    odf=odf.sort_values(['InDate','No']).reset_index(drop=True)
    t0=pd.to_datetime(odf['InDate']).min()
    orders=[]
    for _,r in odf.iterrows():
        pt=products[int(r['Tipe Produk'])]
        arr=(pd.to_datetime(r['InDate'])-t0).total_seconds()/3600.0*TIME_SCALE
        due=(pd.to_datetime(r['Deadline'])-t0).total_seconds()/3600.0*TIME_SCALE
        orders.append(OrderTemplate(int(r['No']),int(r['Prioritas']),int(r['Tipe Produk']),float(r['Running Meter']),
                    str(pd.to_datetime(r['InDate']).date()),str(pd.to_datetime(r['Deadline']).date()),float(arr),float(due),pt.route,pt.width_class,pt.colors))
    # Chronological 35/12/12 split.
    calibration_ids=[o.order_id for o in orders[:35]]
    validation_ids=[o.order_id for o in orders[35:47]]
    heldout_ids=[o.order_id for o in orders[47:59]]
    # Empirical provider-dependent operation duration under frozen physical bridge.
    cal=[o for o in orders if o.order_id in calibration_ids]
    op_hours=[]
    for o in cal:
        for op in o.route:
            if op=='P2b': proc='P2'
            else: proc=op
            feas=[m for m in machines if m.process==proc and (proc!='P1' or m.color_limit is None or m.color_limit>=o.colors)]
            if not feas: continue
            vals=[((o.running_meter/(m.min_speed*m.ratio_speed)+m.setup_min)/60.0)*TIME_SCALE for m in feas]
            op_hours.append(float(np.median(vals)))
    med=float(np.median(op_hours)) if op_hours else 0.298251
    # Calibration slack scale, robust fallback to 8h.
    slacks=[max(1e-6,o.due_h-o.arrival_h) for o in cal]
    slack_scale=float(np.median(slacks)) if slacks else 8.0
    # Base arrival rate is calibrated to bottleneck capability offered load rather than total machine count.
    # Expected workload/order by process from calibration templates.
    proc_classes=('P1','P2','P2b','P3','P4','P5')
    # Offered-load calibration must use *physical* process pools. P2 and P2b are
    # distinct route labels but share the same three lamination machines. Treating
    # them as independent capacities would be physically incorrect.
    physical=('P1','P2','P3','P4','P5')
    demand_work={k:[] for k in physical}
    for o in cal:
        totals={k:0.0 for k in physical}
        for op in o.route:
            proc='P2' if op=='P2b' else op
            feas=[m for m in machines if m.process==proc and (proc!='P1' or m.color_limit is None or m.color_limit>=o.colors)]
            if feas:
                totals[proc]+=min(((o.running_meter/(m.min_speed*m.ratio_speed)+m.setup_min)/60.0)*TIME_SCALE for m in feas)
        for k in physical:demand_work[k].append(totals[k])
    caps={k:sum(1 for m in machines if m.process==k) for k in physical}
    max_lambda=float('inf')
    for k in physical:
        ew=float(np.mean(demand_work[k])) if demand_work[k] else 0.0
        if ew>1e-9: max_lambda=min(max_lambda,caps[k]/ew)
    if not np.isfinite(max_lambda): max_lambda=1.0
    # target rho applied later; this is rho=1 bottleneck rate.
    return EmpiricalBackbone(machines,products,orders,calibration_ids,validation_ids,heldout_ids,proc_classes,med,slack_scale,max_lambda)


def build_calibration_artifact(backbone: EmpiricalBackbone)->dict:
    cal=[o for o in backbone.orders if o.order_id in backbone.calibration_ids]
    mix={k:0.0 for k in backbone.process_classes}
    total=0
    for o in cal:
        for op in o.route:
            mix[op]=mix.get(op,0)+1; total+=1
    mix={k:(v/max(1,total)) for k,v in mix.items()}
    return {
        'evidence_class':'industry-grounded semi-synthetic dynamic cloud-manufacturing simulator',
        'time_scale':TIME_SCALE,
        'volatility_p25':P25_VOL,'volatility_p75':P75_VOL,
        'n_machines':len(backbone.machines),'n_orders':len(backbone.orders),
        'n_calibration':len(backbone.calibration_ids),'n_validation':len(backbone.validation_ids),'n_heldout':len(backbone.heldout_ids),
        'median_operation_h':backbone.median_operation_h,
        'calibration_slack_scale_h':backbone.calibration_slack_scale_h,
        'bottleneck_arrival_rate_rho1':backbone.base_arrival_rate_per_h,
        'capability_mix':mix,
    }

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('--data-root',required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); b=load_backbone(a.data_root); Path(a.out).write_text(json.dumps(build_calibration_artifact(b),indent=2))
