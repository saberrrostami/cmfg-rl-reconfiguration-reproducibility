from __future__ import annotations
import math, json
from pathlib import Path
import numpy as np
from .env import FinalDesignEnv

PRIMARY_NORMAL=0.8503034701138025
PRIMARY_SURGE=1.1496965298861974
PRIMARY_RHO=.80
PRIMARY_MTBF_H=120.0
PRIMARY_REPAIR_H=.35
N_PROVIDERS=15
HORIZON_H=8.0
Q_SWITCH=-math.log(.93)/.25


def analytic_uncertainty_metrics():
    same_1h=.5*(1+math.exp(-2*Q_SWITCH*1.0))
    no_switch_1h=math.exp(-Q_SWITCH*1.0)
    avg_factor=(1-math.exp(-2*Q_SWITCH*1.0))/(2*Q_SWITCH*1.0)
    normal_1h=1+(PRIMARY_NORMAL-1)*avg_factor
    surge_1h=1+(PRIMARY_SURGE-1)*avg_factor
    return {
        'normal_multiplier':PRIMARY_NORMAL,'surge_multiplier':PRIMARY_SURGE,
        'surge_normal_ratio':PRIMARY_SURGE/PRIMARY_NORMAL,
        'switch_rate_per_h':Q_SWITCH,'mean_regime_duration_h':1/Q_SWITCH,
        'one_hour_no_switch_probability':no_switch_1h,
        'one_hour_same_state_probability':same_1h,
        'conditional_mean_multiplier_1h_normal':normal_1h,
        'conditional_mean_multiplier_1h_surge':surge_1h,
        'conditional_one_hour_demand_ratio':surge_1h/normal_1h,
        'expected_system_failures_8h':N_PROVIDERS*HORIZON_H/PRIMARY_MTBF_H,
        'repair_to_horizon_ratio':PRIMARY_REPAIR_H/HORIZON_H,
    }


def uncertainty_learnability_audit(backbone,seeds=(73001,73002,73003,73004),mc_episodes=200):
    a=analytic_uncertainty_metrics()
    rng=np.random.default_rng(99173)
    # Monte-Carlo check of the first-hour signal conditional on known initial regime.
    by={'NORMAL':[],'SURGE':[]}
    for z0 in ('NORMAL','SURGE'):
        for k in range(mc_episodes):
            # Direct exact two-clock CTMC-MMPP simulation over one hour.
            z=z0;t=0.0;n=0
            base=PRIMARY_RHO*backbone.base_arrival_rate_per_h
            while t<1.0:
                rate=base*(PRIMARY_SURGE if z=='SURGE' else PRIMARY_NORMAL)
                da=float(rng.exponential(1/max(1e-9,rate))); ds=float(rng.exponential(1/Q_SWITCH))
                if ds<da:
                    t+=ds
                    if t>=1.0:break
                    z='NORMAL' if z=='SURGE' else 'SURGE'
                else:
                    t+=da
                    if t<1.0:n+=1
            by[z0].append(n)
    mc_ratio=(np.mean(by['SURGE'])+1e-9)/(np.mean(by['NORMAL'])+1e-9)
    a['mc_first_hour_arrivals_normal']=float(np.mean(by['NORMAL']))
    a['mc_first_hour_arrivals_surge']=float(np.mean(by['SURGE']))
    a['mc_first_hour_ratio']=float(mc_ratio)
    a['pass_components']={
        'moderate_spread':a['surge_normal_ratio']<=1.40,
        'persistent_context':a['one_hour_same_state_probability']>=.70,
        'material_but_not_dominant_failures':.5<=a['expected_system_failures_8h']<=2.0,
        'short_repair_relative_horizon':a['repair_to_horizon_ratio']<=.06,
        'predictive_signal_not_extreme':1.15<=a['conditional_one_hour_demand_ratio']<=1.40,
        'mc_signal_consistent':1.08<=a['mc_first_hour_ratio']<=1.50,
    }
    a['status']='PASS' if all(a['pass_components'].values()) else 'FAIL'
    a['interpretation']='Study-specific learnability guardrails; not universal RL thresholds.'
    return a


def save_uncertainty_audit(backbone,out_dir):
    r=uncertainty_learnability_audit(backbone)
    p=Path(out_dir);p.mkdir(parents=True,exist_ok=True);(p/'UNCERTAINTY_LEARNABILITY_GATE.json').write_text(json.dumps(r,indent=2))
    return r
