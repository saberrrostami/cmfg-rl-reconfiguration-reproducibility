from __future__ import annotations

def classify_decision_action(env,d,action_idx:int):
    """Classify the current decision without changing simulator state.

    The exclusive ``decision_class`` describes the relationship between the focal
    operation's current attachment and the selected action.  Recovery allocation is
    intentionally a cross-cutting flag because it can occur on both initial assignment
    and reconfiguration decisions.
    """
    j=env.jobs[d.job_id]; a=d.actions[int(action_idx)]
    old_p=j.current_provider; old_m=j.current_mode
    changed=(old_p is not None and (old_p!=a.provider or old_m!=a.mode))
    if old_p is None:
        cls='initial_assignment'
    elif d.reason=='provider-disruption':
        cls='failure_triggered_change' if changed else 'failure_triggered_keep'
    elif changed:
        cls='queued_reassignment'
    else:
        cls='keep_existing_assignment'
    return {
        'decision_class':cls,
        'trigger':d.reason,
        'prior_attached':bool(old_p is not None),
        'prior_provider':None if old_p is None else int(old_p),
        'prior_mode':old_m,
        'chosen_provider':int(a.provider),
        'chosen_mode':a.mode,
        'chosen_keep_flag':bool(a.keep),
        'provider_changed':bool(old_p is not None and old_p!=a.provider),
        'mode_changed':bool(old_p is not None and old_m!=a.mode),
        'recovery_allocation':bool(a.mode=='recovery'),
        'interrupted_before_decision':bool(j.interrupted),
        'job_status_before_decision':j.status,
    }
