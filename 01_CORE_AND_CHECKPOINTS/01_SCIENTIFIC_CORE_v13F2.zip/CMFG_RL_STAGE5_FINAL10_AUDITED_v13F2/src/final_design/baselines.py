from __future__ import annotations
from dataclasses import dataclass
import math,time,multiprocessing as mp,os
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from .env import FinalDesignEnv,Decision,Action


def action_cost_one_step(env,j,a):
    final_lb=env.projected_order_completion_lb(j,a.provider,a.mode)
    c=env.direct_cost(j,a.provider,a.mode)
    if j.current_provider is not None and (j.current_provider!=a.provider or j.current_mode!=a.mode):
        c += env.kappa*env.b.median_operation_h
    c += max(0.0,final_lb-j.due)*(1+.5*j.priority)
    return c

def select_b0(env,d):
    for i,a in enumerate(d.actions):
        if a.keep:return i
    for i,a in enumerate(d.actions):
        if a.mode=='regular':return i
    return 0

def select_b1(env,d): return int(np.argmin([env.direct_cost(env.jobs[d.job_id],a.provider,a.mode) for a in d.actions]))
def select_b2(env,d):
    vals=[]
    for a in d.actions:
        p=env.providers[a.provider]
        vals.append((1 if a.mode=='recovery' else int(p.available),p.machine.ratio_speed,-env.direct_cost(env.jobs[d.job_id],a.provider,a.mode)))
    return max(range(len(vals)),key=lambda i:vals[i])
def select_b3(env,d): return int(np.argmin([env._projected_completion(env.jobs[d.job_id],a.provider,a.mode) for a in d.actions]))
def select_b4(env,d): return int(np.argmin([action_cost_one_step(env,env.jobs[d.job_id],a) for a in d.actions]))
def select_b5(env,d):
    """Historical S14 B5 retained verbatim for provenance (shadow price = 0)."""
    j=env.jobs[d.job_id]; crit=env.criticality(); vals=[]
    for a in d.actions:
        base=action_cost_one_step(env,j,a); hold=env.service_h(j,a.provider)+(env.recovery_activation_h if a.mode=='recovery' else 0.0)
        vals.append(base+0.0*hold*crit[a.provider]) # historical frozen validation shadow price = 0
    return int(np.argmin(vals))

@dataclass(frozen=True)
class B5OpportunityConfig:
    """Development-tuned opportunity-aware heuristic configuration.

    ``alpha`` multiplies an hour-equivalent opportunity burden.  It is selected only
    on the development-validation seeds; protected/final/audit seeds must never be used
    to choose it.
    """
    alpha:float=1.0


def _opportunity_state(env):
    """Observable provider and shared-recovery pressure, in weighted service-hours.

    Provider pressure mirrors the candidate opportunity feature used by the RL policy:
    each unfinished operation contributes priority-weighted service divided across its
    feasible regular providers.  Shared-recovery pressure is deliberately different:
    it includes only currently at-risk admitted jobs, because recovery is an emergency
    shared resource rather than a regular provider pool.  No realized future event is
    accessed.
    """
    contested=np.zeros(len(env.providers),dtype=float)
    recovery_pressure=0.0
    for jj in env.jobs.values():
        if jj.arrival>env.now or jj.done: continue
        jw=1.0+.5*jj.priority
        for oi in range(jj.op_index,len(jj.route)):
            op=jj.route[oi]; fs=list(env._feasible_for_template_op(jj.template,op))
            if not fs: continue
            for pidx in fs:
                contested[pidx] += jw*env.service_h(jj,pidx)/len(fs)
        if env._at_risk(jj):
            fs=list(env.feasible_providers(jj))
            if fs:
                recovery_pressure += jw*min(env.service_h(jj,pidx) for pidx in fs)
    return contested,float(recovery_pressure)


def opportunity_burden(env,j,a,contested=None,recovery_pressure=None):
    """Current-state opportunity burden in the same hour-equivalent unit as cost.

    Regular actions reserve a specific provider and are penalized by that provider's
    contested load.  Recovery actions do *not* consume the regular provider; instead
    they are penalized by observable at-risk demand for the shared recovery unit.
    Pressure is normalized by the admission horizon so ``alpha`` remains a dimensionless
    development-tuned coefficient.
    """
    if contested is None or recovery_pressure is None:
        contested,recovery_pressure=_opportunity_state(env)
    switched=j.current_provider is not None and (j.current_provider!=a.provider or j.current_mode!=a.mode)
    transfer=env.setup_transfer_h(j,a.provider) if switched else 0.0
    hold=env.service_h(j,a.provider)+transfer+(env.recovery_activation_h if a.mode=='recovery' else 0.0)
    pressure=float(recovery_pressure if a.mode=='recovery' else contested[a.provider])
    return float(hold*pressure/max(1e-9,float(env.horizon)))


class B5OpportunitySelector:
    """Transparent one-step heuristic with an active opportunity-cost term."""
    def __init__(self,cfg:B5OpportunityConfig=B5OpportunityConfig()):
        if cfg.alpha<0: raise ValueError('alpha must be non-negative')
        self.cfg=cfg
    def __call__(self,env,d):
        j=env.jobs[d.job_id]; contested,recovery_pressure=_opportunity_state(env); vals=[]
        for a in d.actions:
            vals.append(action_cost_one_step(env,j,a)+self.cfg.alpha*opportunity_burden(env,j,a,contested,recovery_pressure))
        return int(np.argmin(vals))

@dataclass(frozen=True)
class B6Config:
    lookahead_multiplier:int=4
    scenario_count:int=10
    time_limit_s:float=5.0
    mip_gap:float=.05

def _milp_worker(q,c,integ,lo,hi,M,lbs,ubs,options):
    # Keep native math libraries single-threaded inside each online decision.
    os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1')
    try:
        res=milp(np.asarray(c),integrality=np.asarray(integ),bounds=Bounds(np.asarray(lo),np.asarray(hi)),constraints=LinearConstraint(M,np.asarray(lbs),np.asarray(ubs)),options=options)
        q.put({'ok':True,'status':int(res.status),'x':None if res.x is None else np.asarray(res.x,dtype=float),'mip_gap':None if getattr(res,'mip_gap',None) is None else float(res.mip_gap)})
    except BaseException as e:
        q.put({'ok':False,'error':repr(e)})

class B6RollingHorizon:
    """Sparse stochastic rolling-horizon MILP with hard parent-enforced wall-clock budget.

    Forecast scenarios use only calibration templates and the same observable Markov-modulated
    demand model as the RL environment. Realized future arrivals/failures are never inspected.
    """
    def __init__(self,cfg:B6Config):self.cfg=cfg

    def _calibration_templates(self,env):
        return [env.b.order_by_id(i) for i in env.b.calibration_ids]

    def _sample_future(self,env,rg,h):
        """Exact CTMC-MMPP scenario from the currently observed regime.

        Competing exponential clocks are used for demand arrivals and regime switches.
        This matches the simulator's primary demand law without inspecting realized future
        events.  The same calibration templates are used for sampled job characteristics.
        """
        templates=self._calibration_templates(env); out=[]; t=0.0; regime=env.regime
        q=env.regime_switch_rate_h
        # New arrivals exist only until the environment's admission horizon.  Tasks of
        # jobs admitted before that cutoff may still extend through the rolling horizon.
        arrival_window=min(float(h),max(0.0,float(env.horizon-env.now)))
        while t<arrival_window and len(out)<25:
            rate=max(1e-6,env.rho*env.b.base_arrival_rate_per_h*env.demand_multiplier(regime))
            dt_arr=float(rg.exponential(1.0/rate)); dt_switch=float(rg.exponential(1.0/q))
            if dt_switch < dt_arr:
                t += dt_switch
                if t>=arrival_window: break
                regime='NORMAL' if regime=='SURGE' else 'SURGE'
                continue
            t += dt_arr
            if t>=arrival_window: break
            o=templates[int(rg.integers(0,len(templates)))]; slack=max(.25,o.due_h-o.arrival_h); due_rel=t+slack
            # Approximate the sampled job's full route inside the lookahead using
            # earliest feasible releases. The task cap remains 25.
            rel=t
            for op in o.route:
                if rel>=h or len(out)>=25: break
                out.append((o,op,rel,False,due_rel,o.priority))
                fs=env._feasible_for_template_op(o,op)
                if not fs: break
                class _J: pass
                jj=_J(); jj.template=o
                rel += min(env.service_h(jj,p) for p in fs)
        return out


    def _sample_future_downtime(self,env,rg,h,pidx):
        p=env.providers[pidx]
        start=max(0.0,p.recover_at-env.now) if not p.available else 0.0
        t=start+float(rg.exponential(env.failure_mtbf)); lost=0.0
        while t<h:
            down=float(rg.exponential(env.recovery_mean)); lost += max(0.0,min(h,t+down)-t)
            t += down+float(rg.exponential(env.failure_mtbf))
        return min(h,lost)

    @staticmethod
    def _in_window_work(duration_h:float, release_h:float, capacity_h:float, horizon_h:float)->float:
        """Approximate capacity-hours consumable inside the rolling horizon.

        ``release_h`` is the task's earliest release relative to the current decision.
        ``capacity_h`` is the provider's remaining aggregate capacity after observable
        backlog and sampled downtime.  A task may extend beyond the horizon, but an
        assignment that cannot consume any positive work in the modeled window is not
        allowed to masquerade as an in-window assignment.
        """
        release=max(0.0,float(release_h)); horizon=max(0.0,float(horizon_h))
        cap=max(0.0,float(capacity_h)); dur=max(0.0,float(duration_h))
        temporal=max(0.0,horizon-release)
        return min(dur,cap,temporal)

    @classmethod
    def _future_assignment_terms(cls,duration_h:float,release_h:float,capacity_h:float,horizon_h:float):
        """Return in-window work and explicit carry-over for a future assignment.

        The rolling-horizon MILP is intentionally a capacity-hour approximation rather
        than a sequencing model.  We therefore distinguish three cases explicitly:
        (1) no work can start inside the horizon -> assignment is unavailable and the
            task must use the carry-over/unserved variable;
        (2) the full task fits -> normal assignment;
        (3) only part fits -> assignment is allowed but the residual is charged as
            explicit spill-over in the objective.
        """
        dur=max(0.0,float(duration_h))
        work=cls._in_window_work(dur,release_h,capacity_h,horizon_h)
        if work<=1e-12:
            return None
        spill=max(0.0,dur-work)
        return float(work),float(spill)

    @classmethod
    def _future_assignment_work(cls,duration_h:float,release_h:float,capacity_h:float,horizon_h:float):
        """Backward-compatible Stage-1 API: positive in-window work or ``None``."""
        terms=cls._future_assignment_terms(duration_h,release_h,capacity_h,horizon_h)
        return None if terms is None else float(terms[0])

    @staticmethod
    def _regular_focal_duration(env,j,a):
        """Regular-provider occupation implied by the simulator for focal action ``a``."""
        switched=j.current_provider is not None and (j.current_provider!=a.provider or j.current_mode!='regular')
        transfer=env.setup_transfer_h(j,a.provider) if switched else 0.0
        return env.service_h(j,a.provider)+transfer

    def _recovery_capacity_time(self,env,h):
        # Free units contribute the full horizon; currently occupied units contribute
        # capacity only after their known release. This is observable current-state information.
        cap=float(env.recovery_free)*h
        for release in env.recovery_active.values():
            rem=max(0.0,float(release)-env.now)
            if rem<h: cap += h-rem
        return min(float(env.recovery_units)*h,cap)

    @staticmethod
    def _recovery_earliest_start(env, release_h:float)->float:
        """Observable earliest start on shared recovery capacity, relative to now."""
        rel=max(0.0,float(release_h))
        if env.recovery_free>0:
            return rel
        if not env.recovery_active:
            return float('inf')
        next_free=min(max(0.0,float(t)-env.now) for t in env.recovery_active.values())
        return max(rel,next_free)

    def _known_pipeline(self,env,focal,h,max_tasks=30):
        tasks=[]
        for jj in env.jobs.values():
            if jj.jid==focal.jid or jj.arrival>env.now or jj.done: continue
            if jj.current_provider is not None and jj.status in ('WAITING','PROCESSING'):
                rel=max(0.0,env._projected_completion(jj)-env.now); start=jj.op_index+1
            else:
                rel=0.0; start=jj.op_index
            for oi in range(start,len(jj.route)):
                op=jj.route[oi]
                if rel>=h:break
                tasks.append((jj.template,op,rel,True,max(0.0,jj.due-env.now),jj.priority))
                proc=env._proc_for_op(op); fs=[p.idx for p in env.providers if p.machine.process==proc and (proc!='P1' or p.machine.color_limit is None or p.machine.color_limit>=jj.template.colors)]
                if fs: rel += min(env.service_h(jj,p) for p in fs)
        tasks.sort(key=lambda x:x[2]); return tasks[:max_tasks]

    def select(self,env:FinalDesignEnv,d:Decision):
        st=time.perf_counter(); j=env.jobs[d.job_id]; A=len(d.actions); S=self.cfg.scenario_count; h=self.cfg.lookahead_multiplier*env.b.median_operation_h
        names=[]; c=[]; lo=[]; hi=[]; integ=[]
        def add(name,cost,upper=1.,integer=True):
            i=len(c); names.append(name); c.append(float(cost)); lo.append(0.); hi.append(float(upper)); integ.append(1 if integer else 0); return i
        x=[add(('x',a),action_cost_one_step(env,j,d.actions[a])) for a in range(A)]
        known=self._known_pipeline(env,j,h)
        futures=[]; future_downtime={}
        for s in range(S):
            rg=env._keyrng('b6_v211_ctmc_demand',round(env.now,6),j.jid,s)
            futures.append(known+self._sample_future(env,rg,h))
            for p in env.providers:
                frg=env._keyrng('b6_v208_failure',round(env.now,6),j.jid,s,p.idx)
                future_downtime[(s,p.idx)]=self._sample_future_downtime(env,frg,h,p.idx)
        y={};yr={};u={}; y_terms={}; yr_terms={}
        # ``u`` is the explicit carry-over/unserved variable for a task that cannot be
        # represented by a positive in-window assignment.  Partial spill-over is kept
        # provider-specific through y_terms/yr_terms and charged in the objective.
        for s,tasks in enumerate(futures):
            for k,(o,op,release,is_known,due_rel,priority) in enumerate(tasks):
                proc=env._proc_for_op(op); feas=[p.idx for p in env.providers if p.machine.process==proc and (proc!='P1' or p.machine.color_limit is None or p.machine.color_limit>=o.colors)]
                best_assign=float('inf')
                wlate=(1.0+.5*priority)
                for pidx in feas:
                    p=env.providers[pidx];m=p.machine
                    dur=((o.running_meter/(m.min_speed*m.ratio_speed)+m.setup_min)/60.0)*0.007407407407407408
                    pback=env.provider_backlog_h(pidx)
                    cap=max(0.,h-pback-future_downtime[(s,pidx)])
                    regular_start=max(float(release),float(pback))
                    terms=self._future_assignment_terms(dur,regular_start,cap,h)
                    if terms is not None:
                        work,spill=terms
                        completion=regular_start+dur
                        # Spill is not free: it is a terminal carry-over approximation,
                        # distinct from the in-window service charge and lateness.
                        spill_cost=spill*(1.0+.25*priority)
                        regular_cost=dur+wlate*max(0.0,completion-due_rel)+spill_cost
                        tag='yc' if spill>1e-12 else 'y'
                        y[(s,k,pidx)]=add((tag,s,k,pidx),regular_cost/S)
                        y_terms[(s,k,pidx)]=(work,spill)
                        best_assign=min(best_assign,regular_cost)
                    rcap=self._recovery_capacity_time(env,h)
                    rdur=env.recovery_activation_h+dur
                    recovery_start=self._recovery_earliest_start(env,release)
                    rterms=None if not np.isfinite(recovery_start) else self._future_assignment_terms(rdur,recovery_start,rcap,h)
                    if rterms is not None:
                        rwork,rspill=rterms
                        rcompletion=recovery_start+rdur
                        rspill_cost=rspill*(1.0+.25*priority)
                        recovery_cost=1.35*dur+wlate*max(0.0,rcompletion-due_rel)+rspill_cost
                        rtag='yrc' if rspill>1e-12 else 'yr'
                        yr[(s,k,pidx)]=add((rtag,s,k,pidx),recovery_cost/S)
                        yr_terms[(s,k,pidx)]=(rwork,rspill)
                        best_assign=min(best_assign,recovery_cost)
                # Explicit carry-over penalty.  It is intentionally visible rather than
                # allowing a zero-capacity y/yr assignment to satisfy the equality.
                penalty=(max(0.0,best_assign if np.isfinite(best_assign) else 0.0)+(4.0 if is_known else 3.0)*env.b.median_operation_h*(1+.25*priority))/S
                u[(s,k)]=add(('carry',s,k),penalty)
        rows=[];lbs=[];ubs=[]
        def con(dic,l,hv): rows.append(dic);lbs.append(l);ubs.append(hv)
        con({i:1. for i in x},1.,1.)
        for s,tasks in enumerate(futures):
            for k,_ in enumerate(tasks):
                dic={u[(s,k)]:1.}
                for (ss,kk,pid),i in y.items():
                    if ss==s and kk==k:dic[i]=1.
                for (ss,kk,pid),i in yr.items():
                    if ss==s and kk==k:dic[i]=1.
                con(dic,1.,1.)
        for s,tasks in enumerate(futures):
            for p in env.providers:
                backlog=env.provider_backlog_h(p.idx)
                cap=max(0.,h-backlog-future_downtime[(s,p.idx)]);dic={}
                for aidx,a in enumerate(d.actions):
                    if a.provider==p.idx and a.mode=='regular':
                        # Match simulator semantics: switching transfer/recomposition delay
                        # occupies the selected regular provider before service.
                        dur=self._regular_focal_duration(env,j,a)
                        work=self._in_window_work(dur,backlog,cap,h)
                        if work>1e-12: dic[x[aidx]]=work
                for (ss,k,pid),i in y.items():
                    if ss==s and pid==p.idx:
                        # Work/spill terms were frozen when the assignment variable was
                        # created.  Hence every y/yc variable has strictly positive
                        # in-window capacity consumption.
                        dic[i]=y_terms[(ss,k,pid)][0]
                if dic:con(dic,-np.inf,cap)
            dic={}; rcap=self._recovery_capacity_time(env,h)
            for aidx,a in enumerate(d.actions):
                if a.mode=='recovery':
                    dur=env.recovery_activation_h+env.service_h(j,a.provider)+(env.setup_transfer_h(j,a.provider) if j.current_provider is not None and (j.current_provider!=a.provider or j.current_mode!='recovery') else 0.0)
                    dic[x[aidx]]=self._in_window_work(dur,0.0,rcap,h)
            for (ss,k,pid),i in yr.items():
                if ss==s:
                    dic[i]=yr_terms[(ss,k,pid)][0]
            if dic:con(dic,-np.inf,rcap)
        n=len(c);rr=[];cc=[];vv=[]
        for ri,row in enumerate(rows):
            for ci,v in row.items():rr.append(ri);cc.append(ci);vv.append(v)
        from scipy.sparse import csr_matrix
        M=csr_matrix((vv,(rr,cc)),shape=(len(rows),n))
        build=time.perf_counter()-st; remain=self.cfg.time_limit_s-build
        if remain<=.01:
            return select_b4(env,d),{'status':'BUILD_BUDGET_FALLBACK_B4','timeout':True,'wall_s':time.perf_counter()-st,'build_s':build,'mip_gap':None}
        ctx=mp.get_context('fork') if 'fork' in mp.get_all_start_methods() else mp.get_context()
        q=ctx.Queue(maxsize=1);opts={'time_limit':max(.01,remain),'mip_rel_gap':self.cfg.mip_gap,'presolve':True,'disp':False}
        pr=ctx.Process(target=_milp_worker,args=(q,c,integ,lo,hi,M,lbs,ubs,opts));pr.start();pr.join(timeout=max(.01,remain))
        if pr.is_alive():
            pr.terminate();pr.join(timeout=1.0)
            return select_b4(env,d),{'status':'HARD_TIMEOUT_FALLBACK_B4','timeout':True,'wall_s':time.perf_counter()-st,'build_s':build,'mip_gap':None}
        wall=time.perf_counter()-st
        if q.empty():return select_b4(env,d),{'status':'SOLVER_NO_RESULT_FALLBACK_B4','timeout':False,'wall_s':wall,'build_s':build,'mip_gap':None}
        z=q.get()
        if not z.get('ok') or z.get('x') is None:
            return select_b4(env,d),{'status':'FALLBACK_B4','timeout':bool(z.get('status')==1),'wall_s':wall,'build_s':build,'mip_gap':z.get('mip_gap'),'error':z.get('error')}
        xv=z['x'];a=max(range(A),key=lambda i:xv[x[i]])
        carry_selected=sum(float(xv[i]) for i in u.values())
        partial_spill_selected=sum(float(xv[i])*y_terms[key][1] for key,i in y.items())+sum(float(xv[i])*yr_terms[key][1] for key,i in yr.items())
        return a,{'status':'OPTIMAL' if z['status']==0 else 'INCUMBENT','timeout':bool(z['status']==1),'wall_s':wall,'build_s':build,'mip_gap':z.get('mip_gap'),'variables':n,'constraints':len(rows),'carryover_tasks_selected':carry_selected,'partial_spill_h_selected':partial_spill_selected,'carryover_tasks_selected_mean_scenario':carry_selected/max(1,S),'partial_spill_h_selected_mean_scenario':partial_spill_selected/max(1,S)}

POLICIES={'B0':select_b0,'B1':select_b1,'B2':select_b2,'B3':select_b3,'B4':select_b4,'B5':select_b5} # B5O is Stage-4 explicit/configured only

def run_policy(env,selector,shaped=False,max_decisions=10000):
    d=env.next_decision();n=0
    while d is not None and not env.done and n<max_decisions:
        a=selector(env,d) if callable(selector) else 0;d,_,_,_=env.step(int(a),shaped=shaped);n+=1
    m=env.metrics();tel=env.structural_telemetry();m.update(decisions=n,recovery_binding_fraction=tel['recovery_binding_time_fraction'],bottleneck_utilization=tel['bottleneck_capability_utilization'],critical_provider_utilization=tel['critical_provider_utilization'])
    return m
