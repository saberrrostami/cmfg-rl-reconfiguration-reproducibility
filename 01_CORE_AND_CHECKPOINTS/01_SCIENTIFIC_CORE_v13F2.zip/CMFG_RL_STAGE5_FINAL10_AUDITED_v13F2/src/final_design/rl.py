from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import tempfile, shutil
from typing import List, Dict
import json, math, os, random
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from .obs import Obs,ObsSpec,ObsBuilder
from .models import ActorCritic,DuelingQ

FIELDS_FLOAT=('jobs','providers','candidates','global_features')

def batch_obs(obs:List[Obs],device='cpu'):
    return {
        'jobs':torch.as_tensor(np.stack([o.jobs for o in obs]),dtype=torch.float32,device=device),
        'job_mask':torch.as_tensor(np.stack([o.job_mask for o in obs]),dtype=torch.bool,device=device),
        'providers':torch.as_tensor(np.stack([o.providers for o in obs]),dtype=torch.float32,device=device),
        'provider_mask':torch.as_tensor(np.stack([o.provider_mask for o in obs]),dtype=torch.bool,device=device),
        'candidates':torch.as_tensor(np.stack([o.candidates for o in obs]),dtype=torch.float32,device=device),
        'action_mask':torch.as_tensor(np.stack([o.action_mask for o in obs]),dtype=torch.bool,device=device),
        'global':torch.as_tensor(np.stack([o.global_features for o in obs]),dtype=torch.float32,device=device),
    }

@dataclass
class PPOConfig:
    lr_start:float=3e-4; lr_end:float=1e-4; gamma:float=1.0; gae_lambda:float=.95; clip:float=.20
    entropy_start:float=.01; entropy_end:float=.001; minibatch:int=256; rollout:int=4096; epochs:int=5; max_grad_norm:float=.5; kl_guard:float=.03
    anneal_transitions:int=800_000

class PPO:
    def __init__(self,spec:ObsSpec,cfg:PPOConfig,device='cpu'):
        self.spec=spec; self.cfg=cfg; self.device=device; self.net=ActorCritic(spec).to(device); self.opt=torch.optim.Adam(self.net.parameters(),lr=cfg.lr_start)
    @torch.no_grad()
    def act(self,o:Obs,det=False):
        b=batch_obs([o],self.device); logits,v=self.net(b); dist=Categorical(logits=logits); a=torch.argmax(logits,-1) if det else dist.sample(); return int(a.item()),float(dist.log_prob(a).item()),float(v.item()),float(dist.entropy().item())
    @torch.no_grad()
    def act_batch(self,obs:List[Obs],det=False):
        b=batch_obs(obs,self.device); logits,v=self.net(b); dist=Categorical(logits=logits)
        a=torch.argmax(logits,-1) if det else dist.sample()
        return (a.cpu().numpy().astype(np.int64),dist.log_prob(a).cpu().numpy(),v.cpu().numpy(),dist.entropy().cpu().numpy())
    @torch.no_grad()
    def value_batch(self,obs:List[Obs]):
        if not obs:return np.zeros(0,dtype=np.float32)
        b=batch_obs(obs,self.device); _,v=self.net(b); return v.cpu().numpy()
    @torch.no_grad()
    def action_probs(self,obs:List[Obs]):
        b=batch_obs(obs,self.device); l,_=self.net(b); return torch.softmax(l,-1).cpu().numpy()
    def update(self,roll:List[dict],progress:float):
        if not roll:return {}
        cfg=self.cfg; lr=cfg.lr_start+(cfg.lr_end-cfg.lr_start)*progress; entc=cfg.entropy_start+(cfg.entropy_end-cfg.entropy_start)*progress
        for g in self.opt.param_groups:g['lr']=lr
        adv=np.array([x['adv'] for x in roll],np.float32); adv=(adv-adv.mean())/(adv.std()+1e-8); ret=np.array([x['ret'] for x in roll],np.float32); old=np.array([x['logp'] for x in roll],np.float32); acts=np.array([x['a'] for x in roll],np.int64)
        metrics=[]; n=len(roll); idxall=np.arange(n)
        for ep in range(cfg.epochs):
            np.random.shuffle(idxall)
            stop=False
            for st in range(0,n,cfg.minibatch):
                ix=idxall[st:st+cfg.minibatch]; b=batch_obs([roll[i]['o'] for i in ix],self.device); logits,v=self.net(b); dist=Categorical(logits=logits); at=torch.as_tensor(acts[ix],device=self.device); nl=dist.log_prob(at)
                ratio=torch.exp(nl-torch.as_tensor(old[ix],device=self.device)); A=torch.as_tensor(adv[ix],device=self.device); p1=ratio*A; p2=torch.clamp(ratio,1-cfg.clip,1+cfg.clip)*A; pl=-torch.min(p1,p2).mean(); R=torch.as_tensor(ret[ix],device=self.device); vl=.5*(v-R).pow(2).mean(); en=dist.entropy().mean(); loss=pl+.5*vl-entc*en
                self.opt.zero_grad(); loss.backward(); gn=float(nn.utils.clip_grad_norm_(self.net.parameters(),cfg.max_grad_norm)); self.opt.step()
                kl=float((torch.as_tensor(old[ix],device=self.device)-nl.detach()).mean().abs().item()); cf=float((torch.abs(ratio.detach()-1)>cfg.clip).float().mean()); metrics.append((float(pl.detach().item()),float(vl.detach().item()),float(en.detach().item()),kl,cf,gn))
                if kl>cfg.kl_guard: stop=True; break
            if stop: break
        a=np.array(metrics) if metrics else np.zeros((1,6)); return {'policy_loss':a[:,0].mean(),'value_loss':a[:,1].mean(),'entropy':a[:,2].mean(),'approx_kl':a[:,3].mean(),'clip_fraction':a[:,4].mean(),'grad_norm':a[:,5].mean(),'lr':lr,'entropy_coef':entc}

class PackedReplay:
    """Fixed-width replay with optional file-backed arrays.

    Scientific full D3QN keeps the frozen 100k transition capacity but stores the
    large replay tensors in local file-backed memmap files. Float32 is retained
    end-to-end so observation normalization is not altered by replay compression.
    """
    def __init__(self,s:ObsSpec,capacity=100000,seed=0,backing_dir=None):
        self.s=s; self.cap=int(capacity); self.rng=np.random.default_rng(seed); self.n=0; self.pos=0
        C=self.cap
        self.backing_dir=Path(backing_dir) if backing_dir is not None else None
        if self.backing_dir is not None:
            self.backing_dir.mkdir(parents=True,exist_ok=True)
        self._file_counter=0
        def alloc(shape,dtype,prefix):
            if self.backing_dir is None:
                return np.zeros((C,*shape),dtype)
            self._file_counter += 1
            fn=self.backing_dir/f'{self._file_counter:02d}_{prefix}.mmap'
            return np.memmap(fn,mode='w+',dtype=dtype,shape=(C,*shape))
        def f(shape):return alloc(shape,np.float32,'f32')
        def u(shape):return alloc(shape,np.uint8,'u8')
        self.j=f((s.max_jobs,s.job_dim)); self.jm=u((s.max_jobs,)); self.p=f((s.max_providers,s.provider_dim)); self.pm=u((s.max_providers,)); self.c=f((s.max_actions,s.candidate_dim)); self.am=u((s.max_actions,)); self.g=f((s.global_dim,))
        self.nj=f((s.max_jobs,s.job_dim)); self.njm=u((s.max_jobs,)); self.np_=f((s.max_providers,s.provider_dim)); self.npm=u((s.max_providers,)); self.nc=f((s.max_actions,s.candidate_dim)); self.nam=u((s.max_actions,)); self.ng=f((s.global_dim,))
        self.a=alloc((),np.int16,'action'); self.r=alloc((),np.float32,'reward'); self.done=alloc((),np.uint8,'done')
    def _put(self,prefix,o,i):
        if prefix=='': A=(self.j,self.jm,self.p,self.pm,self.c,self.am,self.g)
        else:A=(self.nj,self.njm,self.np_,self.npm,self.nc,self.nam,self.ng)
        vals=(o.jobs,o.job_mask,o.providers,o.provider_mask,o.candidates,o.action_mask,o.global_features)
        for x,v in zip(A,vals):
            if np.issubdtype(np.asarray(v).dtype,np.floating) and not np.isfinite(v).all():
                raise FloatingPointError('Non-finite observation encountered before replay storage')
            x[i]=v
    def add(self,o,a,r,no,done):
        i=self.pos; self._put('',o,i); self.a[i]=a; self.r[i]=r; self.done[i]=done
        if no is None:
            # terminal next state zeros with no valid actions
            self.nj[i].fill(0); self.njm[i].fill(0); self.np_[i].fill(0); self.npm[i].fill(0); self.nc[i].fill(0); self.nam[i].fill(0); self.ng[i].fill(0)
        else:self._put('n',no,i)
        self.pos=(self.pos+1)%self.cap; self.n=min(self.cap,self.n+1)
    def sample(self,batch,device='cpu'):
        ix=self.rng.integers(0,self.n,size=min(batch,self.n))
        def t(x,dtype):return torch.as_tensor(x[ix],dtype=dtype,device=device)
        bo={'jobs':t(self.j,torch.float32),'job_mask':t(self.jm,torch.bool),'providers':t(self.p,torch.float32),'provider_mask':t(self.pm,torch.bool),'candidates':t(self.c,torch.float32),'action_mask':t(self.am,torch.bool),'global':t(self.g,torch.float32)}
        bn={'jobs':t(self.nj,torch.float32),'job_mask':t(self.njm,torch.bool),'providers':t(self.np_,torch.float32),'provider_mask':t(self.npm,torch.bool),'candidates':t(self.nc,torch.float32),'action_mask':t(self.nam,torch.bool),'global':t(self.ng,torch.float32)}
        return bo,t(self.a,torch.long),t(self.r,torch.float32),bn,t(self.done,torch.float32)
    def __len__(self):return self.n

@dataclass
class D3QNConfig:
    lr:float=1e-4; gamma:float=1.; replay:int=100000; batch:int=128; target_update:int=2000; eps_final:float=.05; warmup:int=5000; update_every:int=4

class D3QN:
    def __init__(self,s:ObsSpec,cfg:D3QNConfig,seed=0,device='cpu',replay_backing_dir=None):
        self.s=s; self.cfg=cfg; self.device=device; self.online=DuelingQ(s).to(device); self.target=DuelingQ(s).to(device); self.target.load_state_dict(self.online.state_dict()); self.opt=torch.optim.Adam(self.online.parameters(),lr=cfg.lr); self.replay=PackedReplay(s,cfg.replay,seed,backing_dir=replay_backing_dir); self.updates=0
    @torch.no_grad()
    def act(self,o:Obs,eps,rng):
        valid=np.flatnonzero(o.action_mask)
        if rng.random()<eps:return int(rng.choice(valid))
        q=self.online(batch_obs([o],self.device)); return int(torch.argmax(q,-1).item())
    @torch.no_grad()
    def greedy_batch(self,obs:List[Obs]):
        if not obs:return np.zeros(0,dtype=np.int64)
        q=self.online(batch_obs(obs,self.device)); return torch.argmax(q,-1).cpu().numpy().astype(np.int64)
    def update(self):
        c=self.cfg
        if len(self.replay)<max(c.batch,c.warmup):return None
        bo,a,r,bn,d=self.replay.sample(c.batch,self.device); q=self.online(bo).gather(1,a[:,None]).squeeze(1)
        with torch.no_grad():
            qno=self.online(bn); # terminal next masks can be all false -> all NEG; force action 0 but multiply by done
            an=torch.argmax(qno,1); qn=self.target(bn).gather(1,an[:,None]).squeeze(1); y=r+c.gamma*qn*(1-d)
        loss=torch.nn.functional.smooth_l1_loss(q,y); self.opt.zero_grad(); loss.backward(); gn=float(nn.utils.clip_grad_norm_(self.online.parameters(),.5)); self.opt.step(); self.updates+=1
        if self.updates%c.target_update==0:self.target.load_state_dict(self.online.state_dict())
        return {'td_loss':float(loss.item()),'q_abs':float(q.detach().abs().mean()),'grad_norm':gn,'replay':len(self.replay)}
