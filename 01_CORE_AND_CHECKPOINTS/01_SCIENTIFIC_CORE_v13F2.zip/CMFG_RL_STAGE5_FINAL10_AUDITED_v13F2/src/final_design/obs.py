from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .env import FinalDesignEnv, Decision, Action

ROUTE_CLASSES=('P1','P2','P2b','P3','P4','P5')

@dataclass(frozen=True)
class ObsSpec:
    # 96 avoids silent truncation under the target family while keeping the MLP/set encoder light.
    max_jobs:int=96
    max_providers:int=15
    max_actions:int=30
    job_dim:int=26
    provider_dim:int=21
    candidate_dim:int=18
    global_dim:int=37

@dataclass
class Obs:
    jobs:np.ndarray
    job_mask:np.ndarray
    providers:np.ndarray
    provider_mask:np.ndarray
    candidates:np.ndarray
    action_mask:np.ndarray
    global_features:np.ndarray
    def copy(self):
        return Obs(*(x.copy() for x in (self.jobs,self.job_mask,self.providers,self.provider_mask,self.candidates,self.action_mask,self.global_features)))

class ObsBuilder:
    def __init__(self,spec:ObsSpec,slack_scale:float,positive_scale:float=1.0):
        self.spec=spec; self.slack_scale=max(1e-6,float(slack_scale)); self.pos_scale=max(1e-6,float(positive_scale)); self._cal_work=None
    def pos(self,x): return np.arcsinh(float(x)/self.pos_scale)
    def build(self,env:FinalDesignEnv,d:Decision)->Obs:
        s=self.spec
        jobs=np.zeros((s.max_jobs,s.job_dim),np.float32); jm=np.zeros(s.max_jobs,bool)
        providers=np.zeros((s.max_providers,s.provider_dim),np.float32); pm=np.zeros(s.max_providers,bool)
        candidates=np.zeros((s.max_actions,s.candidate_dim),np.float32); am=np.zeros(s.max_actions,bool)
        if len(env.providers)>s.max_providers:
            raise RuntimeError(f'Observation provider capacity exceeded: providers={len(env.providers)} > max_providers={s.max_providers}')
        pressure=env.capability_pressure(); dyncrit=env.criticality(); staticcrit=env.calibration_eligibility_criticality(); focal=env.jobs[d.job_id]
        active=[j for j in env.jobs.values() if j.arrival<=env.now and not j.done]
        if len(active)>s.max_jobs:
            raise RuntimeError(f'Observation job capacity exceeded: active={len(active)} > max_jobs={s.max_jobs}')
        active.sort(key=lambda j:(0 if j.jid==focal.jid else 1,j.due,j.jid))
        for r,j in enumerate(active):
            lb=env.lower_bound_remaining(j); slack=j.due-env.now-lb
            feas=len(env.feasible_providers(j)) if not j.done else 0
            frag=0.0; dpe_num=dpe_den=0.0
            if not j.done:
                for oi in range(j.op_index,len(j.route)):
                    op=j.route[oi]; proc=env._proc_for_op(op)
                    fs=list(env._feasible_for_template_op(j.template,op))
                    frag += 1/max(1,len(fs))
                    if fs:
                        w=min(env.service_h(j,p) for p in fs); dpe_num += w*pressure[op][1]; dpe_den+=w
                frag/=max(1,j.remaining_ops)
            dpe=dpe_num/max(1e-6,dpe_den)
            # Queue-position/current-provider summaries reduce state aliasing without
            # exposing a raw provider identifier. Exact queue order remains part of the
            # mathematical simulator state; these are its policy-facing sufficient summaries.
            attached=1.0 if j.current_provider is not None else 0.0
            qrank=0.0; ahead=0.0; cp_static=0.0; cp_dyn=0.0; cp_avail=0.0
            if j.current_provider is not None:
                pp=env.providers[j.current_provider]; cp_static=float(staticcrit[j.current_provider]); cp_dyn=float(dyncrit[j.current_provider]); cp_avail=1.0 if pp.available else 0.0
                if j.jid in pp.queue:
                    qrank=(pp.queue.index(j.jid)+1)/20.0
                    ahead=env.provider_backlog_h(j.current_provider,exclude_jid=j.jid)
                elif j.status=='PROCESSING':
                    ahead=max(0.0,pp.busy_until-env.now)
            op_one=[1.0 if (not j.done and j.op==k) else 0.0 for k in ROUTE_CLASSES]
            base=[
                j.op_index/6.0,j.remaining_ops/6.0,self.pos(lb),np.tanh(slack/self.slack_scale),j.priority/4.0,
                self.pos(max(0,env.now-j.waiting_since)) if j.status=='WAITING' else 0.0,
                1.0 if j.status=='PROCESSING' else 0.0,1.0 if j.interrupted else 0.0,feas/15.0,frag,self.pos(dpe),
                1.0 if j.current_mode=='recovery' else 0.0,(j.due-env.now)/env.hard_cap,1.0 if j.jid==focal.jid else 0.0,
                attached,qrank,self.pos(ahead),cp_static,cp_dyn,cp_avail,
            ]
            jobs[r]=np.asarray(base+op_one,np.float32); jm[r]=True
        # provider features: no raw provider ID or failure-history feature (failure is memoryless).
        for r,p in enumerate(env.providers[:s.max_providers]):
            qwork=sum(env.service_h(env.jobs[jid],p.idx)+max(0.0,env.jobs[jid].pending_transfer_h) for jid in p.queue if jid in env.jobs and not env.jobs[jid].done)
            urgent=sum(1 for jid in p.queue if jid in env.jobs and env.projected_order_completion_lb(env.jobs[jid],p.idx,'regular')>env.jobs[jid].due)
            breadth=sum(1 for k in ROUTE_CLASSES if p.machine.process==env._proc_for_op(k))/len(ROUTE_CLASSES)
            rec_res=max(0.0,p.recover_at-env.now) if not p.available else 0.0
            qjobs=[env.jobs[jid] for jid in p.queue if jid in env.jobs and not env.jobs[jid].done]
            if qjobs:
                head=qjobs[0]; head_slack=head.due-env.now-env.lower_bound_remaining(head); min_slack=min(q.due-env.now-env.lower_bound_remaining(q) for q in qjobs); head_work=env.service_h(head,p.idx)
            else:
                head_slack=min_slack=0.0; head_work=0.0
            providers[r]=np.asarray([
                1.0 if p.available else 0.0,1.0 if p.active_job is not None else 0.0,self.pos(max(0,p.busy_until-env.now)),
                len(p.queue)/20.0,self.pos(qwork),urgent/10.0,p.machine.min_speed/200.0,p.machine.ratio_speed,p.machine.setup_min/150.0,
                breadth,float(staticcrit[p.idx]),float(dyncrit[p.idx]),
                1.0 if p.machine.process=='P1' else 0.0,1.0 if p.machine.process=='P2' else 0.0,1.0 if p.machine.process=='P3' else 0.0,
                1.0 if p.machine.process=='P4' else 0.0,1.0 if p.machine.process=='P5' else 0.0,self.pos(rec_res),
                np.tanh(head_slack/self.slack_scale),np.tanh(min_slack/self.slack_scale),self.pos(head_work)
            ],np.float32); pm[r]=True
        # candidate-relative representation
        # Provider-specific contested load implements the frozen opportunity-cost
        # feature: weighted remaining work that can claim each provider, divided by
        # alternative-set size. P2/P2b share the same physical capability pool.
        contested_by_provider=np.zeros(len(env.providers),dtype=float)
        for jj in active:
            if jj.done: continue
            jw=1.0+.5*jj.priority
            for oi in range(jj.op_index,len(jj.route)):
                op=jj.route[oi]; proc=env._proc_for_op(op)
                fs=list(env._feasible_for_template_op(jj.template,op))
                if not fs: continue
                for pidx in fs:
                    contested_by_provider[pidx] += jw*env.service_h(jj,pidx)/len(fs)
        keep_ref=next((a for a in d.actions if a.keep),None)
        if keep_ref is None and focal.current_provider is not None:
            keep_ref=Action(focal.current_provider,focal.current_mode,True)
        def feat(a):
            p=env.providers[a.provider]
            final_lb=env.projected_order_completion_lb(focal,a.provider,a.mode)
            q=env.provider_backlog_h(a.provider,exclude_jid=(focal.jid if focal.current_provider==a.provider and focal.jid in p.queue else None)) if a.mode=='regular' else 0.0
            switched=focal.current_provider is not None and (focal.current_provider!=a.provider or focal.current_mode!=a.mode)
            st=env.setup_transfer_h(focal,a.provider) if switched else 0.0
            imm=env.direct_cost(focal,a.provider,a.mode)+(env.kappa*env.b.median_operation_h if switched else 0.0)
            sc=float(staticcrit[a.provider]); dc=float(dyncrit[a.provider]); pp=pressure[focal.op][1]
            hold=env.service_h(focal,a.provider)+st+(env.recovery_activation_h if a.mode=='recovery' else 0.0)
            contested=float(contested_by_provider[a.provider])
            return np.asarray([
                final_lb-env.now,q,st,imm,sc,dc,pp,hold*sc,hold*dc,hold*pp,hold*contested,
                1.0 if a.mode=='recovery' else 0.0,1.0 if a.keep else 0.0,(focal.due-final_lb)/env.hard_cap,
                p.machine.ratio_speed,p.machine.setup_min/150.0,env.recovery_activation_h,1.0 if p.available else 0.0
            ],float)
        ref=feat(keep_ref) if keep_ref is not None else np.zeros(s.candidate_dim)
        if len(d.actions)>s.max_actions: raise RuntimeError(f'Action capacity exceeded: {len(d.actions)}>{s.max_actions}')
        for i,a in enumerate(d.actions):
            z=feat(a); z[:4]=z[:4]-ref[:4]
            z[0]=np.tanh(z[0]/2); z[1]=np.arcsinh(z[1]); z[2]=np.arcsinh(z[2]); z[3]=np.arcsinh(z[3])
            # Frozen normalization rule: positive heavy-tailed candidate context
            # is transformed with asinh before entering either neural policy.
            # Indices 6:11 are pipeline pressure and hold-time exposure terms;
            # without this transform provider outages can create extreme values.
            z[6:11]=np.arcsinh(np.maximum(z[6:11],0.0))
            candidates[i]=z.astype(np.float32); am[i]=True
        # global features. Replace constant failure parameters with actionable recovery-release timing.
        util=np.asarray([1.0 if p.active_job is not None else 0.0 for p in env.providers],float)
        prs=[]
        for k in ROUTE_CLASSES: prs.extend([pressure[k][0],pressure[k][1]])
        at_risk=sum(1 for j in active if env._at_risk(j))/max(1,len(active))
        reg=1.0 if env.regime=='SURGE' else 0.0; rmin,rmean=env.shared_recovery_release_summary()
        if self._cal_work is None:
            # Calibration-only expected minimum processing work per arriving order,
            # by route class. Multiplying by the observable-regime arrival rate gives
            # an interpretable expected capability-workload rate without future leakage.
            work={k:0.0 for k in ROUTE_CLASSES}; n=max(1,len(env.b.calibration_ids))
            for oid in env.b.calibration_ids:
                oo=env.b.order_by_id(oid)
                for op in oo.route:
                    fs=list(env._feasible_for_template_op(oo,op))
                    if fs:
                        # service_h only needs template fields and provider characteristics.
                        class _J: pass
                        jj=_J(); jj.template=oo
                        work[op]+=min(env.service_h(jj,p) for p in fs)
            self._cal_work=np.asarray([work[k]/n for k in ROUTE_CLASSES],dtype=np.float32)
        # CTMC-MMPP forecast features.  These are not realized future arrivals; they
        # are conditional expectation moments implied by the observable current regime
        # and the frozen calibration-only demand model.  They make the Markov state
        # explicitly predictive without turning the task into future leakage.
        h_short=.5; h_medium=2.0
        n_short=env.expected_arrivals(h_short); n_medium=env.expected_arrivals(h_medium)
        expected_short=[self.pos(n_short*float(w)) for w in self._cal_work]
        expected_medium=[self.pos(n_medium*float(w)) for w in self._cal_work]
        arrival_window_remaining=max(0.0,env.horizon-env.now)/max(1e-9,env.horizon)
        gf=[len(active)/s.max_jobs,float(util.mean()),float(util.max()),env.recovery_free/max(1,env.recovery_units),1-env.recovery_free/max(1,env.recovery_units),
            at_risk,env.now/env.hard_cap,1-env.now/env.hard_cap,arrival_window_remaining,reg,env.rho,self.pos(rmin),self.pos(rmean),
            *expected_short,*expected_medium,*[np.tanh(x) for x in prs]]
        gf=np.asarray(gf[:s.global_dim],np.float32)
        if len(gf)<s.global_dim: gf=np.pad(gf,(0,s.global_dim-len(gf)))
        return Obs(jobs,jm,providers,pm,candidates,am,gf)
