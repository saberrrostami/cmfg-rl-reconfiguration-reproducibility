from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .env import FinalDesignEnv
from .baselines import select_b4

DEV_SEEDS=tuple(range(62001,62009))

def gate_policy(e,d):
    """Development-only structural policy; uses observable full-route lower-bound urgency."""
    j=e.jobs[d.job_id]
    regs=[(i,a) for i,a in enumerate(d.actions) if a.mode=='regular']
    recs=[(i,a) for i,a in enumerate(d.actions) if a.mode=='recovery']
    if not regs:return 0
    ir,ar=min(regs,key=lambda ia:e.projected_order_completion_lb(j,ia[1].provider,'regular'))
    if e.projected_order_completion_lb(j,ar.provider,'regular')<=j.due or not recs:return ir
    return min(recs,key=lambda ia:e.projected_order_completion_lb(j,ia[1].provider,'recovery'))[0]

def rollout_from(e,selector,stop_after=None):
    start=e.now;c0=e.ledger.total();d=e.pending or e.next_decision();c_at=None
    while d is not None and not e.done:
        if stop_after is not None and c_at is None and e.now-start>=stop_after:c_at=e.ledger.total()-c0
        a=selector(e,d);d,_,_,_=e.step(a,shaped=False)
    tot=e.ledger.total()-c0
    if c_at is None:c_at=tot
    return tot,c_at

def structural_audit(backbone,rho,recovery_units,recovery_activation_h=.10,seeds=DEV_SEEDS,max_probe_states=60):
    comps=[];binds=[];actions=[];critutils=[];caputils=[];cvs=[];probe_states=[];provider_utils=[];max_active=[]
    for seed in seeds:
        e=FinalDesignEnv(backbone,seed,rho=rho,recovery_units=recovery_units,recovery_activation_h=recovery_activation_h)
        d=e.next_decision();dec=0;peak=0
        while d is not None and not e.done:
            active=sum(1 for j in e.jobs.values() if j.arrival<=e.now and not j.done);peak=max(peak,active)
            actions.append(len(d.actions))
            if len(probe_states)<max_probe_states and len(d.actions)>=2 and dec%5==0:probe_states.append(e.clone())
            d,_,_,_=e.step(gate_policy(e,d),shaped=False);dec+=1
        m=e.metrics();tel=e.structural_telemetry();comps.append(m['completion_fraction']);binds.append(tel['recovery_binding_time_fraction']);critutils.append(tel['critical_provider_utilization']);caputils.append(tel['bottleneck_capability_utilization']);provider_utils.append(tel['provider_utilization_time_weighted']);max_active.append(peak)
        cr=e.static_criticality();cvs.append(float(np.std(cr)/(np.mean(cr)+1e-9)))
    disagreements=[];dcis=[];dominant=[]
    h=4*backbone.median_operation_h
    for state in probe_states:
        d=state.pending
        if d is None:continue
        my=select_b4(state,d);vals=[];early=[]
        # Exact within the actual feasible action set (<=30); no top-K truncation.
        for ai in range(len(d.actions)):
            c=state.clone();c.step(ai,shaped=False);tot,ca=rollout_from(c,gate_policy,stop_after=h);vals.append(tot);early.append(ca)
        if not vals:continue
        best=int(np.argmin(vals));disagreements.append(my!=best);dominant.append(best)
        if len(vals)>=2:
            worst=int(np.argmax(vals));diff_total=abs(vals[worst]-vals[best]);diff_early=abs(early[worst]-early[best]);dcis.append(max(0.0,min(1.0,(diff_total-diff_early)/(diff_total+1e-9))))
    domfrac=max([dominant.count(x)/len(dominant) for x in set(dominant)],default=1.0)
    out={
      'rho':rho,'recovery_units':recovery_units,'recovery_activation_h':recovery_activation_h,
      'development_seeds':list(seeds),'completion_fraction_median':float(np.median(comps)),
      'median_feasible_actions':float(np.median(actions)) if actions else 0.0,
      'critical_provider_utilization_median':float(np.median(critutils)),
      'bottleneck_capability_utilization_median':float(np.median(caputils)),
      'recovery_binding_fraction_median':float(np.median(binds)),
      'provider_criticality_cv_median':float(np.median(cvs)),
      'max_active_jobs_observed':int(max(max_active) if max_active else 0),
      'provider_utilization_time_weighted_by_seed':provider_utils,
      'myopic_oracle_disagreement':float(np.mean(disagreements)) if disagreements else 0.0,
      'delayed_consequence_index':float(np.mean(dcis)) if dcis else 0.0,
      'dominant_oracle_action_fraction':domfrac,'probe_states':len(probe_states)
    }
    out['pass_components']={
      'completion':out['completion_fraction_median']>=.90,
      'actions':out['median_feasible_actions']>=3,
      # Physical providers are heterogeneous; critical-provider utilization is the
      # relevant scarcity statistic. The all-capability average is retained diagnostically.
      'utilization':out['critical_provider_utilization_median']>=.80,
      'recovery_binding':.15<=out['recovery_binding_fraction_median']<=.50,
      'criticality':out['provider_criticality_cv_median']>=.20,
      'disagreement':out['myopic_oracle_disagreement']>=.20,
      'dci':out['delayed_consequence_index']>=.20,
      'non_dominance':out['dominant_oracle_action_fraction']<=.80,
      'observation_capacity':out['max_active_jobs_observed']<=96,
    }
    out['status']='PASS' if all(out['pass_components'].values()) else 'FAIL'
    return out

def run_ladder(backbone,out_dir):
    # Fixed pre-RL ladder. The first passing cell is frozen; no PPO/D3QN result is consulted.
    ladder=[(.80,1,.10)]
    reports=[];selected=None
    for rho,rec,act in ladder:
        r=structural_audit(backbone,rho,rec,act,max_probe_states=30);reports.append(r)
        if selected is None and r['status']=='PASS':selected={'rho':rho,'recovery_units':rec,'recovery_activation_h':act,'report':r}
    out={'design_freeze':'CMFG_RL_DESIGN_FREEZE_v2.1.2','audit_revision':'PRE_B_STRUCTURAL_VERIFICATION_v2.1.2_SMDP_FORECAST','reports':reports,'selected':selected,'status':'PASS' if selected else 'FAIL'}
    p=Path(out_dir);p.mkdir(parents=True,exist_ok=True);(p/'STRUCTURAL_GATE.json').write_text(json.dumps(out,indent=2));return out
