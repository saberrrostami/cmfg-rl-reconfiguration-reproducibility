from __future__ import annotations
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from src.final_design.data import load_backbone

def backbone():return load_backbone(ROOT/'data/flexible_packaging')
def outdir(s):p=Path(s);p.mkdir(parents=True,exist_ok=True);return p
