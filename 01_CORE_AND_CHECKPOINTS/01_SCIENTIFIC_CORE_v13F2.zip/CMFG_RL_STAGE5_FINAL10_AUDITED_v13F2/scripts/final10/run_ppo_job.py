from pathlib import Path
import argparse,json,sys,numpy as np
HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'scripts/final_design'))
from common import backbone,outdir
from src.final_design.train import train_ppo
P=argparse.ArgumentParser(); P.add_argument('--output-dir',required=True); P.add_argument('--seed',type=int,required=True); a=P.parse_args()
if a.seed not in [1001,1002,1003,1004,1005]: raise SystemExit('seed must be one of 1001..1005')
r=train_ppo(backbone(),a.seed,outdir(a.output_dir),resume=False,max_steps_override=800000,checkpoint_steps_override=[200000,400000,600000,700000,800000],selection_steps_override=[600000,700000,800000],anneal_transitions_override=800000,n_envs_override=8)
h=r['history']; scores=[float(x['robust_score']) for x in h if int(x.get('step',0)) in [600000,700000,800000]]
if len(scores)!=3: raise SystemExit('missing late checkpoint validation scores')
med=sorted(scores)[1]; spread=100.0*(max(scores)-min(scores))/max(1e-12,abs(med))
r['executed_protocol']='v13-FINAL10-2.0-AUDITED'; r['late_score_spread_percent']=spread; r['late_training_stability_support']=bool(spread<=10.0); r['convergence_claim']=False
# Descriptive late-training trend, not a convergence proof.
late_steps=np.asarray([600000.,700000.,800000.]); late_scores=np.asarray(scores,dtype=float)
coef=float(np.polyfit((late_steps-600000.)/100000.,late_scores,1)[0]) if len(late_scores)==3 else float('nan')
r['late_score_slope_per_100k']=coef; r['diagnostic_validation_steps']=[200000,400000,600000,700000,800000]; r['selection_steps']=[600000,700000,800000]
Path(a.output_dir,f'PPO_seed_{a.seed}_REPORT.json').write_text(json.dumps(r,indent=2))
print(json.dumps({'seed':a.seed,'steps':r['steps_trained'],'selected_step':r['selected_step'],'score':r['selected_robust_score'],'late_spread_pct':spread,'stability_support':r['late_training_stability_support']},indent=2))
