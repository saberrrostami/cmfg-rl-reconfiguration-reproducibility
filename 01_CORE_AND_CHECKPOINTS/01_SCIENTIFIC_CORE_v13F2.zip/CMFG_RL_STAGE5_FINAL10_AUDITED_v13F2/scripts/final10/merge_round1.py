from pathlib import Path
import argparse,json,shutil,numpy as np,subprocess,sys,csv
from collections import Counter
P=argparse.ArgumentParser();P.add_argument('--input-root',required=True);P.add_argument('--output-dir',required=True);a=P.parse_args()
root=Path(a.input_root); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
train=[]
for s in [1001,1002,1003,1004,1005]:
    reps=list(root.rglob(f'PPO_seed_{s}_REPORT.json')); cks=list(root.rglob(f'PPO_seed_{s}_SELECTED.pt'))
    if len(reps)!=1 or len(cks)!=1: raise SystemExit(f'MISSING_OR_DUPLICATE_TRAIN_{s}: reports={len(reps)} ckpts={len(cks)}')
    r=json.loads(reps[0].read_text())
    if int(r.get('steps_trained',0))!=800000 or not r.get('completed_budget_and_numerically_valid',False) or r.get('convergence_claim',True): raise SystemExit(f'INVALID_TRAINING_{s}')
    if list(map(int,r.get('diagnostic_validation_steps',[]))) != [200000,400000,600000,700000,800000]: raise SystemExit(f'INVALID_DIAGNOSTIC_STEPS_{s}')
    if list(map(int,r.get('selection_steps',[]))) != [600000,700000,800000]: raise SystemExit(f'INVALID_SELECTION_STEPS_{s}')
    train.append({'seed':s,'selected_step':int(r['selected_step']),'robust_score':float(r['selected_robust_score']),'median_cost':float(r['selected_validation_median_cost']),'late_spread_pct':float(r['late_score_spread_percent']),'late_slope_per_100k':float(r.get('late_score_slope_per_100k',np.nan)),'stability_support':bool(r['late_training_stability_support'])})
    shutil.copy2(cks[0],out/f'PPO_seed_{s}_SELECTED.pt'); shutil.copy2(reps[0],out/f'PPO_seed_{s}_REPORT.json')
if sum(x['stability_support'] for x in train)<4: raise SystemExit('TRAINING_STABILITY_REVIEW_REQUIRED: fewer than 4/5 seeds have <=10% late-score spread')
# Development-only selection of a deployable single policy. This is secondary; primary remains the training-seed family estimand.
deployment=min(train,key=lambda x:(x['robust_score'],x['median_cost'],x['seed']))

# Combine B6 job shards into four full development configs.
jobs={}
for j in range(6,11):
    hits=list(root.rglob(f'B6_JOB_{j:02d}.json'))
    if len(hits)!=1: raise SystemExit(f'MISSING_OR_DUPLICATE_B6_JOB_{j}: {len(hits)}')
    jobs[j]=json.loads(hits[0].read_text())
configs=[]
for L,S,parts in [(2,25,[6]),(4,10,[7]),(4,25,[8,9]),(8,10,[10])]:
    seeds=[];costs=[];timeouts=fallbacks=ndec=0;statuses=Counter(); lat=[]
    for j in parts:
        z=jobs[j];seeds+=list(map(int,z['validation_seeds']));costs+=list(map(float,z['costs']));timeouts+=int(z['timeouts']);fallbacks+=int(z['fallbacks']);ndec+=int(z['n_decisions']);statuses.update(z.get('status_counts',{}));lat+=list(map(float,z.get('decision_latencies_s',[])))
    if sorted(seeds)!=list(range(70001,70009)): raise SystemExit(f'B6_CONFIG_L{L}_S{S}_SEED_COVERAGE_FAIL')
    med=float(np.median(costs));iqr=float(np.quantile(costs,.75)-np.quantile(costs,.25));fr=fallbacks/max(1,ndec)
    configs.append({'lookahead_multiplier':L,'scenario_count':S,'validation_seeds':sorted(seeds),'costs':costs,'median_cost':med,'iqr_cost':iqr,'robust_score':med+.25*iqr,'timeouts':timeouts,'fallbacks':fallbacks,'fallback_rate':fr,'n_decisions':ndec,'zero_timeout':bool(timeouts==0),'fallback_eligible':bool(fr<=.01),'status_counts':dict(statuses),'median_latency_s':float(np.median(lat)) if lat else 0.0,'p95_latency_s':float(np.quantile(lat,.95)) if lat else 0.0})
zero=[x for x in configs if x['zero_timeout'] and x['fallback_eligible']]
if zero: pool=zero; exception=None
else:
    pool=[x for x in configs if x['fallback_eligible']]
    if not pool: raise SystemExit('NO_B6_CONFIG_WITH_FALLBACK_RATE_LE_1PCT')
    exception='NO_ZERO_TIMEOUT_CONFIG; selected among fallback_rate<=1%'
sel=min(pool,key=lambda x:(x['robust_score'],x['fallback_rate'],x['lookahead_multiplier']*x['scenario_count']))
gate={'status':'PASS_OPEN_FINAL_TEST','protocol':'v13-FINAL10-2.0-AUDITED','training_candidates':train,'training_stability_supported_seeds':sum(x['stability_support'] for x in train),'ppo_primary':'mean of all five independently trained policies per final seed','deployment_training_seed':deployment['seed'],'deployment_selection_basis':'minimum selected development robust score; tie median then seed id','b6_candidates':configs,'b6_selected':{'lookahead_multiplier':sel['lookahead_multiplier'],'scenario_count':sel['scenario_count'],'time_limit_s':5.0,'mip_gap':.05,'development_robust_score':sel['robust_score'],'fallback_rate':sel['fallback_rate'],'timeouts':sel['timeouts'],'median_latency_s':sel['median_latency_s'],'p95_latency_s':sel['p95_latency_s']},'b6_selection_exception':exception,'final_seed_range':[970001,970050],'fixed_n':50,'adaptive_stopping':False,'convergence_claim':False}
(out/'FINAL10_GATE.json').write_text(json.dumps(gate,indent=2))
# Machine-readable summaries.
with (out/'TRAINING_SELECTION_SUMMARY.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(train[0]));w.writeheader();w.writerows(train)
with (out/'B6_DEVELOPMENT_SUMMARY.csv').open('w',newline='') as f:
    fields=['lookahead_multiplier','scenario_count','median_cost','iqr_cost','robust_score','timeouts','fallbacks','fallback_rate','n_decisions','median_latency_s','p95_latency_s','zero_timeout','fallback_eligible'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:x[k] for k in fields} for x in configs])
# Automatic figures.
subprocess.run([sys.executable,str(Path(__file__).with_name('make_figures.py')),'--mode','round1','--input-dir',str(out),'--output-dir',str(out/'figures')],check=True)
print(json.dumps(gate,indent=2))
