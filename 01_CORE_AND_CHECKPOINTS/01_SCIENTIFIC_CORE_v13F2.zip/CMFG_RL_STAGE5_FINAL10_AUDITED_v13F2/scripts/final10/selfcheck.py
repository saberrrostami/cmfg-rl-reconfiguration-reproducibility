from pathlib import Path
import json,sys,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT))
# Run preflight first.
subprocess.run([sys.executable,str(Path(__file__).with_name('preflight.py'))],check=True)
from src.final_design.data import load_backbone
from src.final_design.env import FinalDesignEnv
from src.final_design.baselines import B6RollingHorizon,B6Config
from src.final_design.obs import ObsBuilder,ObsSpec
b=load_backbone(ROOT/'data/flexible_packaging')
# Minimal semantics smoke: one real decision and observation.
e=FinalDesignEnv(b,123456,rho=.80,recovery_units=1,recovery_activation_h=.10,failure_mtbf_h=120.,recovery_mean_h=.35,split='validation')
d=e.next_decision(); assert d is not None and len(d.actions)>0
ob=ObsBuilder(ObsSpec(),b.calibration_slack_scale_h,b.median_operation_h).build(e,d)
assert ob.action_mask.sum()==len(d.actions)
# Repaired B6 carry-over semantics.
assert B6RollingHorizon._future_assignment_terms(0.5,1.0,0.0,2.0) is None
work,spill=B6RollingHorizon._future_assignment_terms(1.0,0.75,1.0,1.0); assert abs(work-.25)<1e-12 and abs(spill-.75)<1e-12
# Protocol firewall.
f=json.loads((ROOT/'FINAL10_PROTOCOL_FREEZE.json').read_text())
train_env_seeds={int(s*100000+i) for s in f['training']['seeds'] for i in range(32)}
final=set(range(f['final_test']['seed_start'],f['final_test']['seed_end']+1)); dev=set(f['training']['development_seeds'])
assert not train_env_seeds & final and not dev & final
print(json.dumps({'status':'PASS','check':'FINAL10_AUDITED_SELF_CHECK','protocol':f['protocol_version'],'one_real_decision_actions':len(d.actions),'final_seed_firewall':True},indent=2))
