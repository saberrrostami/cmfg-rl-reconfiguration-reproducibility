from pathlib import Path
import argparse,csv,json,sys,torch,numpy as np
HERE=Path(__file__).resolve(); ROOT=HERE.parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts/final_design'))
from common import backbone
from src.final_design.env import FinalDesignEnv
from src.final_design.obs import ObsBuilder,ObsSpec
from src.final_design.rl import PPO,PPOConfig
from src.final_design.baselines import B6RollingHorizon,B6Config
P=argparse.ArgumentParser();P.add_argument('--gate-dir',required=True);P.add_argument('--output-dir',required=True);P.add_argument('--job-id',type=int,required=True);a=P.parse_args()
if not 1<=a.job_id<=10: raise SystemExit('job id 1..10')
gd=Path(a.gate_dir); g=json.loads((gd/'FINAL10_GATE.json').read_text());
if g.get('status')!='PASS_OPEN_FINAL_TEST': raise SystemExit('GATE_NOT_OPEN')
start=970001+(a.job_id-1)*5; seeds=range(start,start+5); b=backbone(); device='cuda' if torch.cuda.is_available() else 'cpu'; ob=ObsBuilder(ObsSpec(),b.calibration_slack_scale_h,b.median_operation_h)
agents=[]
for s in [1001,1002,1003,1004,1005]:
 ck=gd/f'PPO_seed_{s}_SELECTED.pt'
 if not ck.exists(): raise SystemExit(f'missing {ck.name}')
 z=torch.load(ck,map_location=device,weights_only=False); ag=PPO(ObsSpec(),PPOConfig(),device); ag.net.load_state_dict(z['model']); ag.net.eval(); agents.append((s,ag))
bc=g['b6_selected']; cfg=B6Config(int(bc['lookahead_multiplier']),int(bc['scenario_count']),float(bc['time_limit_s']),float(bc['mip_gap']))
def env(seed):return FinalDesignEnv(b,seed,rho=.80,recovery_units=1,recovery_activation_h=.10,failure_mtbf_h=120.,recovery_mean_h=.35,split='heldout')
def eval_agent(seed,ag):
 e=env(seed);d=e.next_decision()
 while d is not None and not e.done:
  act=int(ag.act_batch([ob.build(e,d)],det=True)[0][0]);d,_,_,_=e.step(act,shaped=False)
 return e.metrics()
rows=[]
for seed in seeds:
 pcs=[];pcomp=[]; per={}
 p_ledgers=[]
 for ts,ag in agents:
  m=eval_agent(seed,ag); pcs.append(float(m['cost_per_arrived']));pcomp.append(float(m.get('completion_fraction',np.nan)));per[f'ppo_{ts}_cost']=pcs[-1];per[f'ppo_{ts}_completion']=pcomp[-1]
  led={k:float(v)/max(1,int(m['arrived'])) for k,v in m['ledger'].items() if k!='total'}; p_ledgers.append(led)
  for k,v in led.items(): per[f'ppo_{ts}_{k}_per_arrived']=v
 e=env(seed);pol=B6RollingHorizon(cfg);d=e.next_decision();to=fb=dec=0; blat=[]
 while d is not None and not e.done:
  act,m=pol.select(e,d);dec+=1;to+=int(m.get('timeout',False));fb+=int('FALLBACK' in str(m.get('status','')));blat.append(float(m.get('wall_s',0.0)));d,_,_,_=e.step(int(act),shaped=False)
 mb=e.metrics(); barr=max(1,int(mb['arrived'])); bled={k:float(v)/barr for k,v in mb['ledger'].items() if k!='total'}
 fam_led={k:float(np.mean([x[k] for x in p_ledgers])) for k in p_ledgers[0]}
 row={'seed':seed,**per,'ppo_family_mean_cost':float(np.mean(pcs)),'ppo_family_mean_completion':float(np.mean(pcomp)),'b6_cost':float(mb['cost_per_arrived']),'b6_completion':float(mb.get('completion_fraction',np.nan)),'b6_timeouts':to,'b6_fallbacks':fb,'b6_decisions':dec,'b6_median_latency_s':float(np.median(blat)) if blat else 0.0,'b6_p95_latency_s':float(np.quantile(blat,.95)) if blat else 0.0}
 for k,v in fam_led.items(): row[f'ppo_family_{k}_per_arrived']=v
 for k,v in bled.items(): row[f'b6_{k}_per_arrived']=v
 rows.append(row);print(json.dumps(row),flush=True)
out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
with (out/f'FINAL_SHARD_{a.job_id:02d}.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(out/f'FINAL_SHARD_{a.job_id:02d}.json').write_text(json.dumps({'protocol':'v13-FINAL10-2.0-AUDITED','job_id':a.job_id,'seed_range':[start,start+4],'rows':rows},indent=2))
