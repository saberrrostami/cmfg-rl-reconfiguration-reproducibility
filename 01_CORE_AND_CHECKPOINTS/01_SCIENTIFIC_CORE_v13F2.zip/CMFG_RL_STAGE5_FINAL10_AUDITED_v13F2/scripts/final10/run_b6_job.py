from pathlib import Path
import argparse,json,sys,numpy as np
from collections import Counter
HERE=Path(__file__).resolve(); ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'scripts/final_design'))
from common import backbone,outdir
from src.final_design.env import FinalDesignEnv
from src.final_design.baselines import B6RollingHorizon,B6Config
# Use all ten Colabs in round 1: 5 PPO jobs + 5 B6 jobs. The historically slow 4x25 config is sharded in two.
JOBS={6:(2,25,range(70001,70009)),7:(4,10,range(70001,70009)),8:(4,25,range(70001,70005)),9:(4,25,range(70005,70009)),10:(8,10,range(70001,70009))}
P=argparse.ArgumentParser(); P.add_argument('--output-dir',required=True); P.add_argument('--job-id',type=int,required=True); a=P.parse_args()
if a.job_id not in JOBS: raise SystemExit('B6 job id must be 6..10')
L,S,seeds=JOBS[a.job_id]; seeds=list(seeds); b=backbone(); p=outdir(a.output_dir)
costs=[]; timeouts=fallbacks=n=0; statuses=Counter(); lat=[]
for seed in seeds:
 e=FinalDesignEnv(b,seed,rho=.80,recovery_units=1,recovery_activation_h=.10,failure_mtbf_h=120.,recovery_mean_h=.35,split='validation'); pol=B6RollingHorizon(B6Config(L,S,5.0,.05)); d=e.next_decision()
 while d is not None and not e.done:
  act,m=pol.select(e,d); st=str(m.get('status','UNKNOWN')); n+=1; timeouts+=int(m.get('timeout',False)); fallbacks+=int('FALLBACK' in st); statuses[st]+=1; lat.append(float(m.get('wall_s',0.))); d,_,_,_=e.step(int(act),shaped=False)
 costs.append(float(e.metrics()['cost_per_arrived']))
med=float(np.median(costs)); iqr=float(np.quantile(costs,.75)-np.quantile(costs,.25)); fr=fallbacks/max(1,n)
r={'protocol':'v13-FINAL10-2.0-AUDITED','job_id':a.job_id,'lookahead_multiplier':L,'scenario_count':S,'validation_seeds':seeds,'costs':costs,'median_cost_shard':med,'iqr_cost_shard':iqr,'timeouts':timeouts,'fallbacks':fallbacks,'fallback_rate_shard':fr,'n_decisions':n,'status_counts':dict(statuses),'median_latency_s':float(np.median(lat)) if lat else 0.0,'p95_latency_s':float(np.quantile(lat,.95)) if lat else 0.0,'decision_latencies_s':[float(x) for x in lat]}
(p/f'B6_JOB_{a.job_id:02d}.json').write_text(json.dumps(r,indent=2)); print(json.dumps(r,indent=2))
