from pathlib import Path
import json,sys,platform
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
f=json.loads((ROOT/'FINAL10_PROTOCOL_FREEZE.json').read_text())
assert f['protocol_version']=='v13-FINAL10-2.0-AUDITED'
assert f['training']['seeds']==[1001,1002,1003,1004,1005]
assert f['training']['transitions_per_seed']==800000
assert f['training']['diagnostic_validation_steps']==[200000,400000,600000,700000,800000]
assert f['training']['checkpoint_steps']==[600000,700000,800000]
assert f['final_test']['fixed_n']==50 and f['final_test']['seed_start']==970001 and f['final_test']['seed_end']==970050 and f['final_test']['adaptive_stopping'] is False
from src.final_design.train import VALIDATION_SEEDS
assert list(VALIDATION_SEEDS)==f['training']['development_seeds']
from src.final_design.data import load_backbone
b=load_backbone(ROOT/'data/flexible_packaging');assert len(b.calibration_ids)==35 and len(b.validation_ids)==12 and len(b.heldout_ids)==12
import numpy,scipy,torch,matplotlib
r={'status':'PASS','protocol':f['protocol_version'],'python':platform.python_version(),'numpy':numpy.__version__,'scipy':scipy.__version__,'torch':torch.__version__,'matplotlib':matplotlib.__version__,'cuda_available':bool(torch.cuda.is_available()),'cuda_device':(torch.cuda.get_device_name(0) if torch.cuda.is_available() else None),'splits':{'calibration':35,'validation':12,'heldout':12},'training_seeds':f['training']['seeds'],'diagnostic_validation_steps':f['training']['diagnostic_validation_steps'],'selectable_checkpoint_steps':f['training']['checkpoint_steps'],'final_seed_range':[970001,970050],'final_fixed_n':50,'adaptive_stopping':False,'convergence_claim':False}
print(json.dumps(r,indent=2))
