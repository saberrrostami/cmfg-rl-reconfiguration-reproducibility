from pathlib import Path
import argparse,csv,json,numpy as np,subprocess,sys,shutil
P=argparse.ArgumentParser();P.add_argument('--input-root',required=True);P.add_argument('--gate-dir',required=True);P.add_argument('--output-dir',required=True);a=P.parse_args()
root=Path(a.input_root);gd=Path(a.gate_dir);g=json.loads((gd/'FINAL10_GATE.json').read_text());out=Path(a.output_dir);out.mkdir(parents=True,exist_ok=True)
rows=[]
for j in range(1,11):
    hits=list(root.rglob(f'FINAL_SHARD_{j:02d}.csv'))
    if len(hits)!=1: raise SystemExit(f'MISSING_OR_DUPLICATE_SHARD_{j}: {len(hits)}')
    with hits[0].open() as f: rows+=list(csv.DictReader(f))
if len(rows)!=50: raise SystemExit(f'EXPECTED_50_ROWS_GOT_{len(rows)}')
seeds=[int(r['seed']) for r in rows]
if sorted(seeds)!=list(range(970001,970051)): raise SystemExit('FINAL_SEED_FIREWALL_FAIL')
q=np.array([float(r['b6_cost']) for r in rows]); qc=np.array([float(r['b6_completion']) for r in rows])
rng=np.random.default_rng(980001);B=50000;idx=rng.integers(0,50,size=(B,50));sg=rng.choice([-1.,1.],size=(50000,50))
def effect(x,completion=None):
    x=np.asarray(x,float); d=x-q; rel=100*(q-x)/q; absb=d[idx].mean(1); relb=rel[idx].mean(1); stat=abs(d.mean()); pv=(1+np.sum(np.abs((sg*d).mean(1))>=stat))/(50001)
    z={'mean_cost':float(x.mean()),'mean_abs_diff_vs_b6':float(d.mean()),'absolute_ci':list(map(float,np.quantile(absb,[.025,.975]))),'mean_paired_relative_reduction_percent':float(rel.mean()),'relative_ci':list(map(float,np.quantile(relb,[.025,.975]))),'better_seeds':int((d<0).sum()),'signflip_pvalue_absolute_difference':float(pv)}
    if completion is not None:
        cd=100*(np.asarray(completion,float)-qc); cdb=cd[idx].mean(1); z['completion_difference_pp']=float(cd.mean()); z['completion_ci_pp']=list(map(float,np.quantile(cdb,[.025,.975])))
    return z
p=np.array([float(r['ppo_family_mean_cost']) for r in rows]);pc=np.array([float(r['ppo_family_mean_completion']) for r in rows]);fam=effect(p,pc)
# Secondary hierarchical bootstrap resamples both final environment seeds and the five independent training policies.
# The primary paired bootstrap remains conditional on the realized five trained policies.
pmat=np.stack([[float(r[f'ppo_{s}_cost']) for s in [1001,1002,1003,1004,1005]] for r in rows],axis=0)
hrng=np.random.default_rng(980002); HB=20000; hvals=np.empty(HB,float)
for bi in range(HB):
    ei=hrng.integers(0,50,size=50); pi=hrng.integers(0,5,size=5)
    hp=pmat[ei][:,pi].mean(axis=1); hq=q[ei]; hvals[bi]=float((hp-hq).mean())
hier_ci=list(map(float,np.quantile(hvals,[.025,.975])))
per={}
for s in [1001,1002,1003,1004,1005]:
    x=np.array([float(r[f'ppo_{s}_cost']) for r in rows]); xc=np.array([float(r[f'ppo_{s}_completion']) for r in rows]); per[str(s)]=effect(x,xc)
depseed=int(g['deployment_training_seed']); depx=np.array([float(r[f'ppo_{depseed}_cost']) for r in rows]); depc=np.array([float(r[f'ppo_{depseed}_completion']) for r in rows]); dep=effect(depx,depc)
# Accounting component decomposition per arrived order.
components=['service','switch','recovery','restart','tardiness','terminal']; comp={}
for k in components:
    fp=np.array([float(r[f'ppo_family_{k}_per_arrived']) for r in rows]); b=np.array([float(r[f'b6_{k}_per_arrived']) for r in rows]); comp[k]=float((fp-b).mean())
res={'status':'FINAL10_COMPLETE','protocol':'v13-FINAL10-2.0-AUDITED','n':50,'seed_range':[970001,970050],'primary_policy_estimand':'mean of all five PPO policies per final seed','family_effect':fam,'family_hierarchical_training_environment_bootstrap_ci':hier_ci,'hierarchical_bootstrap_replicates':20000,'ppo_family_mean_cost':fam['mean_cost'],'b6_mean_cost':float(q.mean()),'absolute_difference_ppo_minus_b6':fam['mean_abs_diff_vs_b6'],'absolute_ci':fam['absolute_ci'],'signflip_pvalue_absolute_difference':fam['signflip_pvalue_absolute_difference'],'mean_paired_relative_reduction_percent':fam['mean_paired_relative_reduction_percent'],'relative_ci':fam['relative_ci'],'ratio_of_means_reduction_percent':float(100*(q.mean()-p.mean())/q.mean()),'ppo_family_completion':float(pc.mean()),'b6_completion':float(qc.mean()),'completion_difference_pp':fam['completion_difference_pp'],'completion_ci_pp':fam['completion_ci_pp'],'ppo_family_better_seeds':fam['better_seeds'],'per_training_seed_policy':per,'deployment_training_seed':depseed,'deployment_policy_effect':dep,'deployment_selection_basis':g['deployment_selection_basis'],'b6_selected_config':g['b6_selected'],'b6_total_timeouts':sum(int(r['b6_timeouts']) for r in rows),'b6_total_fallbacks':sum(int(r['b6_fallbacks']) for r in rows),'b6_median_seed_median_latency_s':float(np.median([float(r['b6_median_latency_s']) for r in rows])),'b6_p95_seed_p95_latency_s':float(np.quantile([float(r['b6_p95_latency_s']) for r in rows],.95)),'cost_component_difference_ppo_minus_b6':comp,'adaptive_stopping':False,'training_stability_supported_seeds':g['training_stability_supported_seeds'],'convergence_claim':False,'strength_flags':{'family_mean_favors_ppo':bool(fam['mean_abs_diff_vs_b6']<0),'family_absolute_ci_excludes_zero':bool(fam['absolute_ci'][1]<0 or fam['absolute_ci'][0]>0),'all_five_policy_means_favor_ppo':bool(all(per[str(s)]['mean_abs_diff_vs_b6']<0 for s in [1001,1002,1003,1004,1005])),'deployment_mean_favors_ppo':bool(dep['mean_abs_diff_vs_b6']<0)}}
(out/'FINAL_RESULTS.json').write_text(json.dumps(res,indent=2))
with (out/'FINAL_ROWS.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Compact effect table.
with (out/'FINAL_EFFECTS_SUMMARY.csv').open('w',newline='') as f:
    fields=['policy','mean_cost','mean_abs_diff_vs_b6','ci_low','ci_high','mean_paired_relative_reduction_percent','rel_ci_low','rel_ci_high','better_seeds','completion_difference_pp','completion_ci_low','completion_ci_high']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for name,z in [(f'PPO_{s}',per[str(s)]) for s in [1001,1002,1003,1004,1005]]+[('PPO_FAMILY',fam),(f'DEPLOY_PPO_{depseed}',dep)]:
        w.writerow({'policy':name,'mean_cost':z['mean_cost'],'mean_abs_diff_vs_b6':z['mean_abs_diff_vs_b6'],'ci_low':z['absolute_ci'][0],'ci_high':z['absolute_ci'][1],'mean_paired_relative_reduction_percent':z['mean_paired_relative_reduction_percent'],'rel_ci_low':z['relative_ci'][0],'rel_ci_high':z['relative_ci'][1],'better_seeds':z['better_seeds'],'completion_difference_pp':z['completion_difference_pp'],'completion_ci_low':z['completion_ci_pp'][0],'completion_ci_high':z['completion_ci_pp'][1]})
# Bring round-1 diagnostics into final result package.
if (gd/'figures').exists(): shutil.copytree(gd/'figures',out/'round1_figures',dirs_exist_ok=True)
for name in ['TRAINING_SELECTION_SUMMARY.csv','B6_DEVELOPMENT_SUMMARY.csv']:
    if (gd/name).exists(): shutil.copy2(gd/name,out/name)
subprocess.run([sys.executable,str(Path(__file__).with_name('make_figures.py')),'--mode','final','--input-dir',str(out),'--output-dir',str(out/'figures')],check=True)
print(json.dumps(res,indent=2))
