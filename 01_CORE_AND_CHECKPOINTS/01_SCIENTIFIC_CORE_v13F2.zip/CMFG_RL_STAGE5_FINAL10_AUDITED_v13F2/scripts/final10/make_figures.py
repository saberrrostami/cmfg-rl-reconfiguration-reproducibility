from __future__ import annotations
from pathlib import Path
import argparse, csv, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=argparse.ArgumentParser()
P.add_argument('--mode',choices=['round1','final'],required=True)
P.add_argument('--input-dir',required=True)
P.add_argument('--output-dir',required=True)
a=P.parse_args(); inp=Path(a.input_dir); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)

def save(fig,name):
    fig.tight_layout(); fig.savefig(out/name,dpi=220,bbox_inches='tight'); plt.close(fig)

def load_reports():
    reps=[]
    for s in [1001,1002,1003,1004,1005]:
        hits=list(inp.rglob(f'PPO_seed_{s}_REPORT.json'))
        if len(hits)!=1: raise SystemExit(f'need one report for seed {s}, got {len(hits)}')
        reps.append(json.loads(hits[0].read_text()))
    return reps

if a.mode=='round1':
    reps=load_reports()
    # 1) Development validation trajectory: this is the main training-stability/convergence diagnostic.
    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for r in reps:
        h=sorted(r['history'],key=lambda x:int(x['step']))
        x=[int(z['step'])/1000 for z in h]; y=[float(z['robust_score']) for z in h]
        ax.plot(x,y,marker='o',label=f"Seed {r['seed']}")
        ax.scatter([int(r['selected_step'])/1000],[float(r['selected_robust_score'])],marker='*',s=90)
    ax.axvspan(600,800,alpha=.08)
    ax.set_xlabel('Training transitions (thousands)'); ax.set_ylabel('Development robust score (lower is better)')
    ax.set_title('PPO development-validation trajectory')
    ax.legend(ncol=2,fontsize=8)
    save(fig,'FIG_R1_PPO_VALIDATION_TRAJECTORY.png')

    # 2) Probe entropy trajectory: collapse diagnostic, not an optimality measure.
    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for r in reps:
        h=sorted(r['history'],key=lambda x:int(x['step']))
        ax.plot([int(z['step'])/1000 for z in h],[float(z.get('mean_normalized_entropy',np.nan)) for z in h],marker='o',label=f"Seed {r['seed']}")
    ax.set_xlabel('Training transitions (thousands)'); ax.set_ylabel('Mean normalized policy entropy')
    ax.set_title('Fixed-probe policy entropy diagnostic'); ax.legend(ncol=2,fontsize=8)
    save(fig,'FIG_R1_PPO_PROBE_ENTROPY.png')

    # 3) PPO optimization diagnostic (approx KL) at validation checkpoints.
    fig,ax=plt.subplots(figsize=(7.2,4.4))
    for r in reps:
        h=sorted(r['history'],key=lambda x:int(x['step']))
        ax.plot([int(z['step'])/1000 for z in h],[float(z.get('update_metrics',{}).get('approx_kl',np.nan)) for z in h],marker='o',label=f"Seed {r['seed']}")
    ax.axhline(.03,linestyle='--',linewidth=1,label='KL guard')
    ax.set_xlabel('Training transitions (thousands)'); ax.set_ylabel('Approximate KL')
    ax.set_title('PPO update stability diagnostic'); ax.legend(ncol=2,fontsize=8)
    save(fig,'FIG_R1_PPO_APPROX_KL.png')

    gate=json.loads((inp/'FINAL10_GATE.json').read_text()) if (inp/'FINAL10_GATE.json').exists() else None
    if gate:
        cfgs=gate['b6_candidates']; labels=[f"{x['lookahead_multiplier']}x{x['scenario_count']}" for x in cfgs]
        vals=[float(x['robust_score']) for x in cfgs]
        fig,ax=plt.subplots(figsize=(6.5,4.2)); bars=ax.bar(labels,vals)
        ax.set_xlabel('B6 lookahead x scenarios'); ax.set_ylabel('Development robust score (lower is better)'); ax.set_title('Repaired B6 development selection')
        chosen=f"{gate['b6_selected']['lookahead_multiplier']}x{gate['b6_selected']['scenario_count']}"
        for bar,lab,x in zip(bars,labels,cfgs):
            ax.text(bar.get_x()+bar.get_width()/2,bar.get_height(),f"fb={100*x['fallback_rate']:.2f}%\nTO={x['timeouts']}",ha='center',va='bottom',fontsize=7)
            if lab==chosen: bar.set_hatch('//')
        save(fig,'FIG_R1_B6_DEVELOPMENT_SELECTION.png')

        fig,ax=plt.subplots(figsize=(6.5,4.2))
        xs=[float(x.get('median_latency_s',np.nan)) for x in cfgs]
        ys=vals
        ax.scatter(xs,ys,s=60)
        for xx,yy,lab in zip(xs,ys,labels): ax.annotate(lab,(xx,yy),xytext=(4,4),textcoords='offset points',fontsize=8)
        ax.set_xlabel('Median solver latency per decision (s)'); ax.set_ylabel('Development robust score')
        ax.set_title('B6 quality-time trade-off on development')
        save(fig,'FIG_R1_B6_QUALITY_TIME.png')

elif a.mode=='final':
    rows=[]
    with (inp/'FINAL_ROWS.csv').open() as f: rows=list(csv.DictReader(f))
    res=json.loads((inp/'FINAL_RESULTS.json').read_text())
    p=np.array([float(r['ppo_family_mean_cost']) for r in rows]); q=np.array([float(r['b6_cost']) for r in rows])
    pc=np.array([float(r['ppo_family_mean_completion']) for r in rows]); qc=np.array([float(r['b6_completion']) for r in rows])
    d=p-q
    # 1) Paired primary cost scatter.
    fig,ax=plt.subplots(figsize=(5.5,5.1)); ax.scatter(q,p,alpha=.75)
    lo=float(min(q.min(),p.min())); hi=float(max(q.max(),p.max())); ax.plot([lo,hi],[lo,hi],linestyle='--',linewidth=1)
    ax.set_xlabel('Repaired B6 cost / arrived order'); ax.set_ylabel('Five-policy PPO family mean cost / arrived order')
    ax.set_title('Primary paired final-test comparison')
    save(fig,'FIG_FINAL_PAIRED_COST_SCATTER.png')

    # 2) Sorted paired differences.
    fig,ax=plt.subplots(figsize=(7.4,4.2)); sd=np.sort(d); ax.plot(np.arange(1,len(sd)+1),sd,marker='o',linestyle='none',markersize=4); ax.axhline(0,linestyle='--',linewidth=1)
    ax.set_xlabel('Final seed (sorted by paired difference)'); ax.set_ylabel('PPO family mean - B6 cost')
    ax.set_title('Distribution of paired final-test cost differences')
    save(fig,'FIG_FINAL_PAIRED_DIFFERENCES.png')

    # 3) Per-training-seed robustness forest, including family and deployment policy.
    names=[]; means=[]; los=[]; his=[]
    for s in ['1001','1002','1003','1004','1005']:
        z=res['per_training_seed_policy'][s]; names.append(f'PPO {s}'); means.append(z['mean_abs_diff_vs_b6']); los.append(z['absolute_ci'][0]); his.append(z['absolute_ci'][1])
    z=res['family_effect']; names.append('PPO family'); means.append(z['mean_abs_diff_vs_b6']); los.append(z['absolute_ci'][0]); his.append(z['absolute_ci'][1])
    z=res['deployment_policy_effect']; names.append(f"Deploy {res['deployment_training_seed']}"); means.append(z['mean_abs_diff_vs_b6']); los.append(z['absolute_ci'][0]); his.append(z['absolute_ci'][1])
    y=np.arange(len(names)); m=np.asarray(means); loe=m-np.asarray(los); hie=np.asarray(his)-m
    fig,ax=plt.subplots(figsize=(7.2,4.8)); ax.errorbar(m,y,xerr=np.vstack([loe,hie]),fmt='o',capsize=3); ax.axvline(0,linestyle='--',linewidth=1); ax.set_yticks(y,names); ax.invert_yaxis(); ax.set_xlabel('Mean absolute cost difference vs B6 (negative favors PPO)'); ax.set_title('Training-seed robustness and deployment policy')
    save(fig,'FIG_FINAL_POLICY_ROBUSTNESS_FOREST.png')

    # 4) Completion scatter.
    fig,ax=plt.subplots(figsize=(5.5,5.1)); ax.scatter(qc,pc,alpha=.75); lo=float(min(qc.min(),pc.min())); hi=float(max(qc.max(),pc.max())); ax.plot([lo,hi],[lo,hi],linestyle='--',linewidth=1); ax.set_xlabel('B6 completion fraction'); ax.set_ylabel('PPO family completion fraction'); ax.set_title('Paired completion comparison')
    save(fig,'FIG_FINAL_COMPLETION_SCATTER.png')

    # 5) Cost-component accounting difference.
    comp=res.get('cost_component_difference_ppo_minus_b6',{})
    if comp:
        keys=['service','switch','recovery','restart','tardiness','terminal']; vals=[float(comp[k]) for k in keys]
        fig,ax=plt.subplots(figsize=(7.2,4.2)); ax.bar(keys,vals); ax.axhline(0,linestyle='--',linewidth=1); ax.set_ylabel('PPO family - B6 cost / arrived order'); ax.set_title('Accounting decomposition of the final cost difference'); ax.tick_params(axis='x',rotation=25)
        save(fig,'FIG_FINAL_COST_DECOMPOSITION.png')
