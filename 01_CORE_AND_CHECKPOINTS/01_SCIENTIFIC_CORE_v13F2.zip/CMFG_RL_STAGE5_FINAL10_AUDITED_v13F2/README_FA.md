# CMFG v13 FINAL10 v2 — نسخه ممیزی‌شده پیش از ران

این بسته قبل از اجرای محاسبات نهایی برای جلوگیری از دوباره‌کاری ممیزی شده است.

## پروتکل علمی
- 5 training seeds مستقل: 1001..1005
- 800k transition برای هر seed
- diagnostic validation: 200k, 400k, 600k, 700k, 800k
- انتخاب checkpoint فقط از 600k/700k/800k و فقط روی development
- primary estimand: میانگین پنج policy در هر final seed در برابر B6 repaired
- secondary deployable policy: یک training seed که فقط با development انتخاب می‌شود
- B6 repaired از چهار config فقط روی development انتخاب می‌شود
- Final test: 50 seed تازه 970001..970050، fixed-N، بدون adaptive stopping
- هیچ ادعای mathematical convergence وجود ندارد؛ فقط fixed-budget completion و late-training stability گزارش می‌شود.

## شکل‌های خودکار
پس از MERGE1:
- PPO development-validation trajectory
- fixed-probe entropy
- PPO approximate-KL diagnostic
- B6 development selection
- B6 quality-time trade-off

پس از MERGE_FINAL:
- paired PPO-family vs B6 cost scatter
- paired difference distribution
- per-policy + deployment-policy forest plot with 95% bootstrap CIs
- completion scatter
- cost-component accounting decomposition

تمام CSV/JSONهای لازم همراه شکل‌ها ذخیره می‌شوند.
