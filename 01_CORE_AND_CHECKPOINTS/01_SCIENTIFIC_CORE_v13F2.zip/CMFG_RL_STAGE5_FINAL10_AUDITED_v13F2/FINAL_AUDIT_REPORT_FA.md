# ممیزی نهایی پیش از اجرای v13 FINAL10 v2

## تصمیم
این نسخه برای اجرای نهایی توصیه می‌شود. مدل علمی v13 نسبت به Stage 4 تغییر نکرده است؛ تغییرات این دور فقط diagnostic/reporting/selection discipline هستند.

## اصلاحات پیش از ران
1. پنج training seed و بودجه 800k حفظ شد.
2. validation diagnostic در 200k/400k/600k/700k/800k ثبت می‌شود؛ انتخاب checkpoint فقط از 600k/700k/800k است.
3. نمودار development-validation trajectory به‌عنوان شاهد training stability تولید می‌شود؛ هیچ ادعای mathematical convergence مجاز نیست.
4. entropy ثابت‌پروب، approximate-KL، B6 selection و quality-time به‌طور خودکار رسم می‌شوند.
5. یک policy قابل استقرار فقط با development انتخاب و نتیجه final آن جداگانه گزارش می‌شود؛ primary result همچنان family-of-five estimand است.
6. Final Test همچنان N=50، fixed-N و بدون adaptive stopping است.
7. برای هر پنج PPO، CI و اثر مستقل گزارش می‌شود.
8. علاوه بر paired bootstrap اصلی، hierarchical bootstrap ثانویه training+environment uncertainty اضافه شد.
9. service/switch/recovery/restart/tardiness/terminal decomposition در final output ذخیره و رسم می‌شود.
10. latency، timeout و fallback B6 در development و final گزارش می‌شوند.

## شکل‌های خودکار
### پس از MERGE1
- FIG_R1_PPO_VALIDATION_TRAJECTORY.png
- FIG_R1_PPO_PROBE_ENTROPY.png
- FIG_R1_PPO_APPROX_KL.png
- FIG_R1_B6_DEVELOPMENT_SELECTION.png
- FIG_R1_B6_QUALITY_TIME.png

### پس از MERGE_FINAL
- FIG_FINAL_PAIRED_COST_SCATTER.png
- FIG_FINAL_PAIRED_DIFFERENCES.png
- FIG_FINAL_POLICY_ROBUSTNESS_FOREST.png
- FIG_FINAL_COMPLETION_SCATTER.png
- FIG_FINAL_COST_DECOMPOSITION.png

## ریسک باقیمانده
هیچ ممیزی کد نمی‌تواند مثبت‌بودن نتیجه empirical را تضمین کند. ریسک اصلی اکنون علمی است، نه نرم‌افزاری: repaired B6 ممکن است فاصله PPO را کاهش دهد و CI ممکن است صفر را قطع نکند. Gate آموزش قبل از Final Test از اجرای confirmatory روی training ناپایدار جلوگیری می‌کند.
